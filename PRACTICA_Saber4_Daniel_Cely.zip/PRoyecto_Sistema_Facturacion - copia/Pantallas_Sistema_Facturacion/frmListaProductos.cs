﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MaterialSkin;
using MaterialSkin.Controls;

namespace Pantallas_Sistema_Facturacion
{
    public partial class frmListaProductos : MaterialForm
    {
        //************************************************************************ Instancia de la clase acceso_Datos  **************************************//
        acceso_Datos acceso = new acceso_Datos();
        public frmListaProductos()
        {
            InitializeComponent();
            dgvProductos.AutoGenerateColumns = false;
        }

        private void frmListaProductos_Load(object sender, EventArgs e)
        {
            llenar_grid_productos();
        }
        //**************************************************************  Metodo para llenar la tabla de productos  *****************************************//
        public void llenar_grid_productos(string filtro="")
        {

            try
            {
                string condicion = ""; // si el usuario no ingresa ningun filtro, se cargan todos los productos
                if (!string.IsNullOrEmpty(filtro))
                {
                    condicion = $"WHERE StrNombre LIKE '%{filtro}%' OR StrCodigo LIKE '%{filtro}%'"; // asi se filtran los productos por nombre o codigo
                }
                DataTable dt = acceso.cargarTabla("TBLPRODUCTO", condicion); // Llamamos al método cargarTabla de la clase acceso_Datos para obtener los productos de la base de datos
                dgvProductos.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar los productos: " + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // ----------------------------------------------------------- METODO PARA AGREGAR NUEVOS PRODUCTOS ------------------------------------------------- //
        private void btnProductoNuevo_Click(object sender, EventArgs e)
        {
            frmProductos productos = new frmProductos(0); // Abrimos el formulario de productos con idProducto = 0 para indicar que es un nuevo producto
            if (productos.ShowDialog() == DialogResult.OK)
            {
                llenar_grid_productos();
            }
        }

        // ----------------------------------------------------------- METODO PARA EDITAR / BORRAr PRODUCTOS ------------------------------------------------- //
        private void dgvProductos_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
            if (e.RowIndex < 0) return;// Verificamos que el índice de la fila sea válido


            // cuadno se hace click en el boton de editar, se abre el formulario de edición con los datos del producto seleccionado
            if (dgvProductos.Columns[e.ColumnIndex].Name == "colEditar")
            {
                int idProducto = Convert.ToInt32(dgvProductos.Rows[e.RowIndex].Cells["colId"].Value);// Obtenemos el ID del producto de la fila seleccionada

                frmProductos productoForm = new frmProductos(idProducto);// Abrimos el formulario de edición pasando el ID

                if (productoForm.ShowDialog() == DialogResult.OK)
                {
                    llenar_grid_productos(); // Refrescamos la lista tras editar
                }
            }

            // Cuando se hace click en el botón de eliminar, se elimina el producto seleccionado
            if (dgvProductos.Columns[e.ColumnIndex].Name == "colBorrar")
            {
                int idProducto = Convert.ToInt32(dgvProductos.Rows[e.RowIndex].Cells["colId"].Value);
                string nombre = dgvProductos.Rows[e.RowIndex].Cells["colProducto"].Value.ToString();

                DialogResult result = MessageBox.Show($"¿Está seguro de eliminar el producto '{nombre}'?",
                                                      "Confirmar Eliminación",
                                                      MessageBoxButtons.YesNo,
                                                      MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    // Ejecutamos el procedimiento almacenado o comando de eliminación
                    string sentencia = $"EXEC Eliminar_Producto {idProducto}";
                    string respuesta = acceso.EjecutarComando(sentencia);

                    MessageBox.Show(respuesta, "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    llenar_grid_productos(); // Refrescamos la lista tras eliminar
                }
            }
        }

        private void txtBuscar_Click(object sender, EventArgs e)
        {
            llenar_grid_productos(txtBuscar.Text.Trim());
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            llenar_grid_productos(txtBuscar.Text.Trim());

        }
        private void txtBuscar_TextChanged(object sender, EventArgs e)
        {
            llenar_grid_productos(txtBuscar.Text.Trim());
        }
    }
}
