﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MaterialSkin;
using MaterialSkin.Controls;


namespace Pantallas_Sistema_Facturacion
{
    public partial class frmInformes : MaterialForm
    {
        public frmInformes()
        {
            InitializeComponent();
        }
        // -- ******************************************************************************** -- //
        private bool ValidarCampos()
        {
            bool esValido = true;
            errorProvider1.Clear(); // 

            // 1. Validar Tipo Selección de Informe ComboBox
            if (cboSeleccioneInforme.SelectedIndex == -1 || string.IsNullOrWhiteSpace(cboSeleccioneInforme.Text))
            {
                errorProvider1.SetError(cboSeleccioneInforme, "Debe seleccionar el tipo de informe.");
                esValido = false;
            }

            // 
            if (dtpFechaInicio.Value > dtpFechaFinal.Value)
            {
                errorProvider1.SetError(dtpFechaFinal, "La fecha final no puede ser menor a la fecha inicial.");
                esValido = false;
            }

            // 
            if (cboOrdenarPor.SelectedIndex == -1 || string.IsNullOrWhiteSpace(cboOrdenarPor.Text))
            {
                errorProvider1.SetError(cboOrdenarPor, "Debe seleccionar un criterio de ordenamiento.");
                esValido = false;
            }

            return esValido;
        }
        // -- ******************************************************************************** -- //
        private void frmInformes_Load(object sender, EventArgs e)
        {

        }
        // -- *************************************************************************************************** -- //
        private void btnGenerarInforme_Click(object sender, EventArgs e)
        {
            if (!ValidarCampos())
            {
                MessageBox.Show("Por favor, complete los campos obligatorios indicados.",
                                "Validación de datos",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
                return;
            }

            MessageBox.Show("Factura actualizada con éxito.",
                            "Sistema de Facturación",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
        }
        // -- ******************************************************************************** -- //

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        
    }
}
