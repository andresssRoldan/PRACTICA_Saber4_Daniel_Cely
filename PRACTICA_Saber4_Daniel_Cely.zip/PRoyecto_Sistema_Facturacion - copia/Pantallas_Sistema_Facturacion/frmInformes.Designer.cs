﻿namespace Pantallas_Sistema_Facturacion
{
    partial class frmInformes
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblTitulo = new MaterialSkin.Controls.MaterialLabel();
            this.lblSeleccioneInforme = new MaterialSkin.Controls.MaterialLabel();
            this.cboSeleccioneInforme = new System.Windows.Forms.ComboBox();
            this.lblOrdenarPor = new MaterialSkin.Controls.MaterialLabel();
            this.cboOrdenarPor = new System.Windows.Forms.ComboBox();
            this.lblFechaInicio = new MaterialSkin.Controls.MaterialLabel();
            this.dtpFechaInicio = new System.Windows.Forms.DateTimePicker();
            this.lblFechaFinal = new MaterialSkin.Controls.MaterialLabel();
            this.dtpFechaFinal = new System.Windows.Forms.DateTimePicker();
            this.rbEnPantalla = new MaterialSkin.Controls.MaterialRadioButton();
            this.rbPdf = new MaterialSkin.Controls.MaterialRadioButton();
            this.rbExcel = new MaterialSkin.Controls.MaterialRadioButton();
            this.btnGenerarInforme = new MaterialSkin.Controls.MaterialRaisedButton();
            this.btnSalir = new MaterialSkin.Controls.MaterialRaisedButton();
            this.panelVisorInforme = new System.Windows.Forms.Panel();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Depth = 0;
            this.lblTitulo.Font = new System.Drawing.Font("Roboto", 11F);
            this.lblTitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblTitulo.Location = new System.Drawing.Point(220, 80);
            this.lblTitulo.MouseState = MaterialSkin.MouseState.HOVER;
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(324, 19);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "GENERADOR DE INFORMES DE FACTURACIÓN";
            // 
            // lblSeleccioneInforme
            // 
            this.lblSeleccioneInforme.AutoSize = true;
            this.lblSeleccioneInforme.Depth = 0;
            this.lblSeleccioneInforme.Font = new System.Drawing.Font("Roboto", 11F);
            this.lblSeleccioneInforme.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblSeleccioneInforme.Location = new System.Drawing.Point(50, 125);
            this.lblSeleccioneInforme.MouseState = MaterialSkin.MouseState.HOVER;
            this.lblSeleccioneInforme.Name = "lblSeleccioneInforme";
            this.lblSeleccioneInforme.Size = new System.Drawing.Size(176, 19);
            this.lblSeleccioneInforme.TabIndex = 1;
            this.lblSeleccioneInforme.Text = "SELEACCIONE INFORME";
            // 
            // cboSeleccioneInforme
            // 
            this.cboSeleccioneInforme.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSeleccioneInforme.FormattingEnabled = true;
            this.cboSeleccioneInforme.Location = new System.Drawing.Point(232, 123);
            this.cboSeleccioneInforme.Name = "cboSeleccioneInforme";
            this.cboSeleccioneInforme.Size = new System.Drawing.Size(200, 21);
            this.cboSeleccioneInforme.TabIndex = 2;
            // 
            // lblOrdenarPor
            // 
            this.lblOrdenarPor.AutoSize = true;
            this.lblOrdenarPor.Depth = 0;
            this.lblOrdenarPor.Font = new System.Drawing.Font("Roboto", 11F);
            this.lblOrdenarPor.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblOrdenarPor.Location = new System.Drawing.Point(450, 125);
            this.lblOrdenarPor.MouseState = MaterialSkin.MouseState.HOVER;
            this.lblOrdenarPor.Name = "lblOrdenarPor";
            this.lblOrdenarPor.Size = new System.Drawing.Size(87, 19);
            this.lblOrdenarPor.TabIndex = 3;
            this.lblOrdenarPor.Text = "Ordenar por";
            // 
            // cboOrdenarPor
            // 
            this.cboOrdenarPor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboOrdenarPor.FormattingEnabled = true;
            this.cboOrdenarPor.Location = new System.Drawing.Point(550, 125);
            this.cboOrdenarPor.Name = "cboOrdenarPor";
            this.cboOrdenarPor.Size = new System.Drawing.Size(150, 21);
            this.cboOrdenarPor.TabIndex = 4;
            // 
            // lblFechaInicio
            // 
            this.lblFechaInicio.AutoSize = true;
            this.lblFechaInicio.Depth = 0;
            this.lblFechaInicio.Font = new System.Drawing.Font("Roboto", 11F);
            this.lblFechaInicio.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblFechaInicio.Location = new System.Drawing.Point(100, 165);
            this.lblFechaInicio.MouseState = MaterialSkin.MouseState.HOVER;
            this.lblFechaInicio.Name = "lblFechaInicio";
            this.lblFechaInicio.Size = new System.Drawing.Size(90, 19);
            this.lblFechaInicio.TabIndex = 5;
            this.lblFechaInicio.Text = "Fecha Inicio";
            // 
            // dtpFechaInicio
            // 
            this.dtpFechaInicio.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFechaInicio.Location = new System.Drawing.Point(220, 165);
            this.dtpFechaInicio.Name = "dtpFechaInicio";
            this.dtpFechaInicio.Size = new System.Drawing.Size(120, 20);
            this.dtpFechaInicio.TabIndex = 6;
            // 
            // lblFechaFinal
            // 
            this.lblFechaFinal.AutoSize = true;
            this.lblFechaFinal.Depth = 0;
            this.lblFechaFinal.Font = new System.Drawing.Font("Roboto", 11F);
            this.lblFechaFinal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblFechaFinal.Location = new System.Drawing.Point(400, 165);
            this.lblFechaFinal.MouseState = MaterialSkin.MouseState.HOVER;
            this.lblFechaFinal.Name = "lblFechaFinal";
            this.lblFechaFinal.Size = new System.Drawing.Size(85, 19);
            this.lblFechaFinal.TabIndex = 7;
            this.lblFechaFinal.Text = "Fecha Final";
            // 
            // dtpFechaFinal
            // 
            this.dtpFechaFinal.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFechaFinal.Location = new System.Drawing.Point(500, 165);
            this.dtpFechaFinal.Name = "dtpFechaFinal";
            this.dtpFechaFinal.Size = new System.Drawing.Size(120, 20);
            this.dtpFechaFinal.TabIndex = 8;
            // 
            // rbEnPantalla
            // 
            this.rbEnPantalla.AutoSize = true;
            this.rbEnPantalla.Depth = 0;
            this.rbEnPantalla.Font = new System.Drawing.Font("Roboto", 10F);
            this.rbEnPantalla.Location = new System.Drawing.Point(220, 205);
            this.rbEnPantalla.Margin = new System.Windows.Forms.Padding(0);
            this.rbEnPantalla.MouseLocation = new System.Drawing.Point(-1, -1);
            this.rbEnPantalla.MouseState = MaterialSkin.MouseState.HOVER;
            this.rbEnPantalla.Name = "rbEnPantalla";
            this.rbEnPantalla.Ripple = true;
            this.rbEnPantalla.Size = new System.Drawing.Size(98, 30);
            this.rbEnPantalla.TabIndex = 9;
            this.rbEnPantalla.TabStop = true;
            this.rbEnPantalla.Text = "En Pantalla";
            this.rbEnPantalla.UseVisualStyleBackColor = true;
            // 
            // rbPdf
            // 
            this.rbPdf.AutoSize = true;
            this.rbPdf.Depth = 0;
            this.rbPdf.Font = new System.Drawing.Font("Roboto", 10F);
            this.rbPdf.Location = new System.Drawing.Point(340, 205);
            this.rbPdf.Margin = new System.Windows.Forms.Padding(0);
            this.rbPdf.MouseLocation = new System.Drawing.Point(-1, -1);
            this.rbPdf.MouseState = MaterialSkin.MouseState.HOVER;
            this.rbPdf.Name = "rbPdf";
            this.rbPdf.Ripple = true;
            this.rbPdf.Size = new System.Drawing.Size(50, 30);
            this.rbPdf.TabIndex = 10;
            this.rbPdf.TabStop = true;
            this.rbPdf.Text = "Pdf";
            this.rbPdf.UseVisualStyleBackColor = true;
            // 
            // rbExcel
            // 
            this.rbExcel.AutoSize = true;
            this.rbExcel.Depth = 0;
            this.rbExcel.Font = new System.Drawing.Font("Roboto", 10F);
            this.rbExcel.Location = new System.Drawing.Point(430, 205);
            this.rbExcel.Margin = new System.Windows.Forms.Padding(0);
            this.rbExcel.MouseLocation = new System.Drawing.Point(-1, -1);
            this.rbExcel.MouseState = MaterialSkin.MouseState.HOVER;
            this.rbExcel.Name = "rbExcel";
            this.rbExcel.Ripple = true;
            this.rbExcel.Size = new System.Drawing.Size(62, 30);
            this.rbExcel.TabIndex = 11;
            this.rbExcel.TabStop = true;
            this.rbExcel.Text = "Excel";
            this.rbExcel.UseVisualStyleBackColor = true;
            // 
            // btnGenerarInforme
            // 
            this.btnGenerarInforme.Depth = 0;
            this.btnGenerarInforme.Location = new System.Drawing.Point(220, 250);
            this.btnGenerarInforme.MouseState = MaterialSkin.MouseState.HOVER;
            this.btnGenerarInforme.Name = "btnGenerarInforme";
            this.btnGenerarInforme.Primary = true;
            this.btnGenerarInforme.Size = new System.Drawing.Size(150, 35);
            this.btnGenerarInforme.TabIndex = 12;
            this.btnGenerarInforme.Text = "GENERAR INFORME";
            this.btnGenerarInforme.UseVisualStyleBackColor = true;
            this.btnGenerarInforme.Click += new System.EventHandler(this.btnGenerarInforme_Click);
            // 
            // btnSalir
            // 
            this.btnSalir.Depth = 0;
            this.btnSalir.Location = new System.Drawing.Point(400, 250);
            this.btnSalir.MouseState = MaterialSkin.MouseState.HOVER;
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Primary = true;
            this.btnSalir.Size = new System.Drawing.Size(120, 35);
            this.btnSalir.TabIndex = 13;
            this.btnSalir.Text = "SALIR";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // panelVisorInforme
            // 
            this.panelVisorInforme.BackColor = System.Drawing.Color.DimGray;
            this.panelVisorInforme.Location = new System.Drawing.Point(50, 305);
            this.panelVisorInforme.Name = "panelVisorInforme";
            this.panelVisorInforme.Size = new System.Drawing.Size(650, 220);
            this.panelVisorInforme.TabIndex = 14;
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // frmInformes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(750, 550);
            this.Controls.Add(this.panelVisorInforme);
            this.Controls.Add(this.btnSalir);
            this.Controls.Add(this.btnGenerarInforme);
            this.Controls.Add(this.rbExcel);
            this.Controls.Add(this.rbPdf);
            this.Controls.Add(this.rbEnPantalla);
            this.Controls.Add(this.dtpFechaFinal);
            this.Controls.Add(this.lblFechaFinal);
            this.Controls.Add(this.dtpFechaInicio);
            this.Controls.Add(this.lblFechaInicio);
            this.Controls.Add(this.cboOrdenarPor);
            this.Controls.Add(this.lblOrdenarPor);
            this.Controls.Add(this.cboSeleccioneInforme);
            this.Controls.Add(this.lblSeleccioneInforme);
            this.Controls.Add(this.lblTitulo);
            this.Name = "frmInformes";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Informes";
            this.Load += new System.EventHandler(this.frmInformes_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MaterialSkin.Controls.MaterialLabel lblTitulo;
        private MaterialSkin.Controls.MaterialLabel lblSeleccioneInforme;
        private System.Windows.Forms.ComboBox cboSeleccioneInforme;
        private MaterialSkin.Controls.MaterialLabel lblOrdenarPor;
        private System.Windows.Forms.ComboBox cboOrdenarPor;
        private MaterialSkin.Controls.MaterialLabel lblFechaInicio;
        private System.Windows.Forms.DateTimePicker dtpFechaInicio;
        private MaterialSkin.Controls.MaterialLabel lblFechaFinal;
        private System.Windows.Forms.DateTimePicker dtpFechaFinal;
        private MaterialSkin.Controls.MaterialRadioButton rbEnPantalla;
        private MaterialSkin.Controls.MaterialRadioButton rbPdf;
        private MaterialSkin.Controls.MaterialRadioButton rbExcel;
        private MaterialSkin.Controls.MaterialRaisedButton btnGenerarInforme;
        private MaterialSkin.Controls.MaterialRaisedButton btnSalir;
        private System.Windows.Forms.Panel panelVisorInforme;
        private System.Windows.Forms.ErrorProvider errorProvider1;
    }
}