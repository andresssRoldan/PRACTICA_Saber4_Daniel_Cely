﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MaterialSkin;
using MaterialSkin.Controls;

namespace Pantallas_Sistema_Facturacion
{
    public partial class frmEmpleados : MaterialForm
    {
        // Instancia de la capa de datos
        acceso_Datos acceso = new acceso_Datos();

        // Variable global para almacenar el ID que viene desde frmListaEmpleados (0 = Nuevo, >0 = Editar)
        private int idEmpleadoSeleccionado = 0;

        
        public frmEmpleados(int idEmpleado = 0)
        {
            InitializeComponent();
            idEmpleadoSeleccionado = idEmpleado;
        }

        private void frmEmpleados_Load(object sender, EventArgs e)
        {
            CargarRoles();

            // Si viene un ID mayor a 0, estamos EDITANDO y cargamos la información del empleado
            if (idEmpleadoSeleccionado > 0)
            {
                CargarDatosEmpleado(idEmpleadoSeleccionado);
            }
        }

        // --------------------------------------------------------------------- Método para llenar el ComboBox de Roles------------------------------- //
        private void CargarRoles()
        {
            try
            {
                // 1. Cargamos los roles desde la base de datos
                DataTable dtRoles = acceso.cargarTabla("TBLROLES", "");

                // Configuramos el ComboBox para mostrar la descripción y almacenar el ID del rol
                cboRol_frmEmpleados.DisplayMember = "strDescripcion";
                cboRol_frmEmpleados.ValueMember = "IdRolEmpleado";

                // 2. Asignamos la lista
                cboRol_frmEmpleados.DataSource = dtRoles;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar roles: " + ex.Message);
            }
        }

        // ------------------------------------------------------- Método para cargar los datos del empleado si se hace clic en Editar -----------------//
        private void CargarDatosEmpleado(int id)
        {
            try
            {
                DataTable dt = acceso.cargarTabla("TBLEMPLEADO", $"WHERE IdEmpleado = {id}");
                if (dt != null && dt.Rows.Count > 0)
                {
                    DataRow row = dt.Rows[0];
                    txtNombre_frmEmpleados.Text = row["StrNombre"].ToString();
                    txtDocumento_frmEmpleados.Text = row["NumDocumento"].ToString();
                    txtDireccion_frmEmpleados.Text = row["StrDireccion"].ToString();
                    txtTelefono_frmEmpleados.Text = row["StrTelefono"].ToString();
                    txtEmail_frmEmpleados.Text = row["StrEmail"].ToString();

                    if (row["IdRolEmpleado"] != DBNull.Value)
                        cboRol_frmEmpleados.SelectedValue = row["IdRolEmpleado"];

                    if (row["DtmIngreso"] != DBNull.Value)
                        dtpFechaIngreso_frmEmpleados.Value = Convert.ToDateTime(row["DtmIngreso"]);

                    if (row["DtmRetiro"] != DBNull.Value)
                        dtpFechaRetiro_frmEmpleados.Value = Convert.ToDateTime(row["DtmRetiro"]);

                    txtDatosAdicionales_frmEmpleados.Text = row["strDatosAdicionales"].ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar datos del empleado: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // -------------------------------------------------------------- Validación de campos del formulario ---------------------//
        private bool ValidarCampos()
        {
            bool esValido = true;
            errorProvider1.Clear();

            if (string.IsNullOrWhiteSpace(txtNombre_frmEmpleados.Text))
            {
                errorProvider1.SetError(txtNombre_frmEmpleados, "El nombre del empleado es obligatorio.");
                esValido = false;
            }

            if (string.IsNullOrWhiteSpace(txtDocumento_frmEmpleados.Text))
            {
                errorProvider1.SetError(txtDocumento_frmEmpleados, "El número de documento es obligatorio.");
                esValido = false;
            }

            if (string.IsNullOrWhiteSpace(txtDireccion_frmEmpleados.Text))
            {
                errorProvider1.SetError(txtDireccion_frmEmpleados, "La dirección es obligatoria.");
                esValido = false;
            }

            if (string.IsNullOrWhiteSpace(txtTelefono_frmEmpleados.Text))
            {
                errorProvider1.SetError(txtTelefono_frmEmpleados, "El teléfono es obligatorio.");
                esValido = false;
            }

            if (string.IsNullOrWhiteSpace(txtEmail_frmEmpleados.Text))
            {
                errorProvider1.SetError(txtEmail_frmEmpleados, "El correo electrónico es obligatorio.");
                esValido = false;
            }

            if (cboRol_frmEmpleados.SelectedIndex == -1 || string.IsNullOrWhiteSpace(cboRol_frmEmpleados.Text))
            {
                errorProvider1.SetError(cboRol_frmEmpleados, "Debe seleccionar un rol para el empleado.");
                esValido = false;
            }

            if (dtpFechaRetiro_frmEmpleados.Value.Date < dtpFechaIngreso_frmEmpleados.Value.Date)
            {
                errorProvider1.SetError(dtpFechaRetiro_frmEmpleados, "La fecha de retiro no puede ser anterior a la fecha de ingreso.");
                esValido = false;
            }

            return esValido;
        }

        //  ------------------------------------------- Botón Guardar / Actualizar Empleado en la BD -------------------------------------------//
        private void btnActualizar_frmEmpleados_Click(object sender, EventArgs e)
        {
            if (!ValidarCampos())
            {
                MessageBox.Show("Por favor, complete los campos obligatorios indicados.",
                                "Validación de datos",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
                return;
            }

            try
            {
                int idRol = Convert.ToInt32(cboRol_frmEmpleados.SelectedValue);

                // -- Formateamos las fechas al formato adecuado para SQL Server (yyyyMMdd)            
                string fechaIngreso = dtpFechaIngreso_frmEmpleados.Value.ToString("yyyyMMdd");
                string fechaRetiro = dtpFechaRetiro_frmEmpleados.Value.ToString("yyyyMMdd");
                string fechaModifica = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                // Construimos la sentencia SQL para actualizar el empleado
                string sentencia = $@"EXEC actualizar_Empleado 
                @IdEmpleado = {idEmpleadoSeleccionado},
                @strNombre = '{txtNombre_frmEmpleados.Text.Trim()}',
                @NumDocumento = '{txtDocumento_frmEmpleados.Text.Trim()}',
                @strDireccion = '{txtDireccion_frmEmpleados.Text.Trim()}',
                @strTelefono = '{txtTelefono_frmEmpleados.Text.Trim()}',
                @strEmail = '{txtEmail_frmEmpleados.Text.Trim()}',
                @IdRolEmpleado = {idRol},
                @DtmIngreso = '{fechaIngreso}',
                @DtmRetiro = '{fechaRetiro}',
                @strDatosAdicionales = '{txtDatosAdicionales_frmEmpleados.Text.Trim()}',
                @DtmFechaModifica = '{fechaModifica}',
                @strUsuarioModifico = 'admin'";

                acceso.EjecutarComandoDatos(sentencia);

                MessageBox.Show("Empleado actualizado con éxito.",
                                "Sistema de Facturación",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Information);

                this.DialogResult = DialogResult.OK; 
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar el empleado: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSalir_frmEmpleados_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}