﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Pantallas_Sistema_Facturacion
{
    public class acceso_Datos
    {
        SqlConnection conexion; // definicion de variable para la conexion a la base de datos
        SqlCommand cmd;// definimos variable para ejecutar comandos en la base de datos
        SqlDataReader lectorDatos = null; // definimos variable para leer datos de la base de datos
        SqlDataAdapter da; // definimos variable para llenar un dataset con los datos de la base de datos
        DataTable dt; // definimos variable para llenar un datatable con los datos de la base de datos
        DataSet ds; // definimos variable para llenar un dataset con los datos de la base de datos


        // ---------------------------------------------------------- METODO PARA ABRIR Y CERRAR LA CONEXION A LA BASE DE DATOS ------------------------ //
        public void abrirBd()
        {
            try 
            { // creamos un objeto de tipo conexión a la base de datos y se pasa como parámetro la cadena de conexión 
                string cadenaConexion = @"Data Source=.\SQLEXPRESS;Initial Catalog=[DBFACTURAS];Integrated Security=True;";
                conexion = new SqlConnection(cadenaConexion);
                conexion.Open(); // invocamos método para abrir la base de datos 
            }
            catch (Exception ex) // si hay error presenta el siguiente mensaje
            {
                MessageBox.Show("Error al abrir la base de datos: " + ex.Message);
            }
        }

        public void cerrarBd()// metodo para cerrar la conexion a la base de datos
        {
            try //Permite capturar errores en tiempo de ejecución y manejar excepciones de manera controlada.
            {
                conexion.Close(); // invocamos método para cerrar la base de datos 
            }
            catch (Exception ex) // si hay error presenta el siguiente mensaje
            {
                MessageBox.Show("Error al cerrar la base de datos: " + ex.Message);
            }
        }


        // ------------------------------------------------------- METODO PARA VALIDACION DE USUARIO Y CLAVE --------------------------------------------- //

        public string validarUsuario(string strUsuario, string strClave)
        {
            try
            {
                string strEmpleado = "";
                string sentencia = $"select e.strNombre, e.IdRolEmpleado from TBLSEGURIDAD s JOIN TBLEMPLEADO " +
                    $"e ON s.IdEmpleado = e.IdEmpleado WHERE s.strUsuario = '{strUsuario}' AND s.strClave = '{strClave}'";
                abrirBd();
                cmd = new SqlCommand();

                cmd.Connection = conexion;// asignamos la conexion a la base de datos
                cmd.CommandText = sentencia;// asignamos la sentencia SQL a ejecutar
                cmd.CommandType = CommandType.Text;// asignamos el tipo de comando a ejecutar otros tipos de comando son: StoredProcedure, TableDirect
                cmd.CommandTimeout = 10;// asignamos el tiempo de espera para ejecutar el comando
                lectorDatos = cmd.ExecuteReader();// ejecutamos el comando y asignamos el resultado a la variable lectorDatos

                while (lectorDatos.Read())// mientras haya datos en el lectorDatos
                {
                    strEmpleado = Convert.ToString(lectorDatos.GetValue(0));
                }
                if (lectorDatos != null)
                {
                    lectorDatos.Close();
                }
                return strEmpleado;
            }
            catch (Exception ex) // si hay error presenta el siguiente mensaje
            {
                MessageBox.Show("Error al validar usuario: " + ex.Message);
                return "";
            }
        }

        // ----------------------------------------------------------- Método consultar con una sentencia (select) procedimiento almacenado --------// 
        public DataTable EjecutarComandoDatos(string cmd)
        {
            try
            {
                abrirBd();
                da = new SqlDataAdapter(cmd, conexion);
                dt = new DataTable(); // Llenamos directamente el DataTable
                da.Fill(dt);
                cerrarBd();
                return dt; // CORREGIDO: Retorna el DataTable cargado con los datos

            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR EN LA CONSULTA: " + ex.ToString());
                return null;
            }
        }
        // ----------------  -- METODO PARA EJECUTAR COMANDOS DE ACTUALIZACION, ELIMINACION Y CREACION DE REGISTROS EN LA BASE DE DATOS ------- //

        public string EjecutarComando(string sentencia)
        {
            string salida = "LOS DATOS SE ACTUALIZARON SATISFACTORIAMENTE!";

            try
            {
                int retornado;
                abrirBd();
                cmd = new SqlCommand(sentencia, conexion);
                retornado = cmd.ExecuteNonQuery(); // UTILIZADO PARA UPDATE, INSERT y DELETE 
                cerrarBd();
                if (retornado > 0)
                {
                    salida = "Los datos fueron Actualizados";
                }
                else
                {
                    salida = "Los datos no fueron Actualizados";
                }
            }
            catch (Exception ex)
            {
                salida = "falló inserción: " + ex;
            }
            return salida;
        }

        // ------------------------ METODO PARA  LLENAR UN DATATABLE CON LOS DATOS DE LA BASE DE DATOS ------------------------ //

        public DataTable cargarTabla(string tabla, string strCondicion)
        {
            try
            {
                abrirBd();
                string Sql = "Select * from " + tabla + " " + strCondicion;
                da = new SqlDataAdapter(Sql, conexion);
                ds = new DataSet();
                da.Fill(ds, tabla);
                dt = new DataTable();
                dt = ds.Tables[tabla];
                cerrarBd();
                return dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR EN LA CONSULTA: " + ex.ToString());
                cerrarBd();
                return null;
                
            }
        }
       
    }
}
