﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MaterialSkin;
using MaterialSkin.Controls;

namespace Pantallas_Sistema_Facturacion
{
    public partial class frmAdminSeguridad : MaterialForm
    {
        // Instancia global de la clase acceso_Datos
        acceso_Datos Acceso = new acceso_Datos();
        public frmAdminSeguridad()
        {
            InitializeComponent();
        }

        // ---- ******************************* METDO para cargar datos de empleados a cboEmpleado_frmAdminSeguridad ********************************************* -- //
        private void Llenar_Combo_Empleados()
        {
            // Carga la tabla TBLEMPLEADO mediante la clase de datos
            DataTable dt = Acceso.cargarTabla("TBLEMPLEADO", "");
            if (dt != null && dt.Rows.Count > 0)
            {
                cboEmpleado_frmAdminSeguridad.DataSource = dt;
                cboEmpleado_frmAdminSeguridad.DisplayMember = "strNombre";
                cboEmpleado_frmAdminSeguridad.ValueMember = "IdEmpleado";
            }
        }
        // ---- ****************************************** Invocacr Evento Load del formulario ********************************************* -- //
        private void frmAdminSeguridad_Load(object sender, EventArgs e)
        {
            // llama al método para llenar el combo de empleados al cargar el formulario
            Llenar_Combo_Empleados();
        }

        //--- ******************** Funcion para consultar si el usuario ya existe en la TBL  base de datos ********************************************* -- //

        public void ConsultarUsuarioExistente(string strUsuario)
        {
            if (cboEmpleado_frmAdminSeguridad.SelectedValue != null)
            {
                string idEmp = cboEmpleado_frmAdminSeguridad.SelectedValue.ToString();
                string sentencia = $"select StrUsuario, StrClave from TBLSEGURIDAD where IdEmpleado = {idEmp}";
                DataTable dt = Acceso.EjecutarComandoDatos(sentencia);

                if (dt != null && dt.Rows.Count > 0)
                {
                    txtUsuario_frmAdminSeguridad.Text = dt.Rows[0]["StrUsuario"].ToString();
                    txtClave_frmAdminSeguridad.Text = dt.Rows[0]["StrClave"].ToString();
                }
                else
                {
                    MessageBox.Show("El empleado seleccionado no dispone de datos de ingreso registrados.");
                    txtUsuario_frmAdminSeguridad.Text = "";
                    txtClave_frmAdminSeguridad.Text = "";
                }
            }
        }

        // --- ****************************  FUNCION PARA GUARDAR O ACTUALIZAR DATOS DE SEGURIDAD EN LA BASE DE DATOS ********************************* -- //

        public bool Guardar()
        {
            bool actualizado = false;
            if (ValidarCampos()) //  Usa la función ValidarCampos para verificar si los campos obligatorios están completos
            {
                try
                {
                    int idEmpleado = Convert.ToInt32(cboEmpleado_frmAdminSeguridad.SelectedValue);
                    string usuario = txtUsuario_frmAdminSeguridad.Text.Trim();
                    string clave = txtClave_frmAdminSeguridad.Text.Trim();
                    string fecha = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                    // Invocación del procedimiento almacenado
                    string sentencia = $"Exec actualizar_Seguridad '{idEmpleado}', '{usuario}', '{clave}', '{fecha}', 'Javier'";

                    MessageBox.Show(Acceso.EjecutarComando(sentencia));
                    actualizado = true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Falló inserción: " + ex.Message);
                    actualizado = false;
                }
            }
            return actualizado;
        }


        // ---- ***************************************************** Funcion  Validar campos obligatorios ********************************************* -- //
        private bool ValidarCampos()
        {
            bool esValido = true;
            errorProvider1.Clear(); // Limpia marcas de error previas

            // 1. Validar Empleado (ComboBox)
            if (cboEmpleado_frmAdminSeguridad.SelectedIndex == -1 || string.IsNullOrWhiteSpace(cboEmpleado_frmAdminSeguridad.Text))
            {
                errorProvider1.SetError(cboEmpleado_frmAdminSeguridad, "Debe seleccionar un empleado.");
                esValido = false;
            }

            // 2. Validar Usuario
            if (string.IsNullOrWhiteSpace(txtUsuario_frmAdminSeguridad.Text))
            {
                errorProvider1.SetError(txtUsuario_frmAdminSeguridad, "El nombre de usuario es obligatorio.");
                esValido = false;
            }

            // 3. Validar Clave / Contraseña
            if (string.IsNullOrWhiteSpace(txtClave_frmAdminSeguridad.Text))
            {
                errorProvider1.SetError(txtClave_frmAdminSeguridad, "La clave de acceso es obligatoria.");
                esValido = false;
            }

            return esValido;
        }
        
        // Evento Click para el botón Actualizar
        private void btnActualizar_frmAdminSeguridad_Click(object sender, EventArgs e)
        {
            Guardar();
        }
        // -- *************************************************************************** -- //
        // Evento Click para el botón Salir
        private void btnSalir_frmAdminSeguridad_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }

}
