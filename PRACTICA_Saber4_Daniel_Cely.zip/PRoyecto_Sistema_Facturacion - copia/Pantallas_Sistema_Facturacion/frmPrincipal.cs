﻿using System;
using MaterialSkin;
using MaterialSkin.Controls;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pantallas_Sistema_Facturacion
{
    public partial class frmPrincipal : MaterialForm
    {
        public frmPrincipal()
        {
            InitializeComponent();
        }      

        private void btnClientes_Click(object sender, EventArgs e)
        {
            //  Limpiamos cualquier contenido anterior del panel
            if (this.pnlContenedor.Controls.Count > 0)
                this.pnlContenedor.Controls.RemoveAt(0);

            //  Instanciamos el formulario de la lista de clientes
            frmListaClientes frm = new frmListaClientes();

            //  Lo configuramos como formulario hijo para incrustarlo
            frm.TopLevel = false;
            frm.FormBorderStyle = FormBorderStyle.None;
            frm.Dock = DockStyle.Fill;

            // le agregamos al panel contenedor y lo mostramos
            this.pnlContenedor.Controls.Add(frm);
            this.pnlContenedor.Tag = frm;
            frm.Show();
        }
        
        private void btnCategorias_Click(object sender, EventArgs e)
        {
            frmCategoriasProductos frm = new frmCategoriasProductos();
            frm.ShowDialog();
        }

        private void btnProductos_Click(object sender, EventArgs e)
        {
            frmListaProductos frm = new frmListaProductos();
            
            frm.TopLevel = false;
            frm.FormBorderStyle = FormBorderStyle.None;
            frm.Dock = DockStyle.Fill;

            // 3. Limpiamos el panel contenedor principal de frmPrincipal
            pnlContenedor.Controls.Clear(); // Cambia 'pnlContenedor' por el nombre de tu Panel en frmPrincipal

            // 4. Agregamos el formulario al panel y lo mostramos
            pnlContenedor.Controls.Add(frm);
            pnlContenedor.Tag = frm;
            frm.Show();


        }

        private void btnInformes_Click(object sender, EventArgs e)
        {
            frmInformes frm = new frmInformes();
            frm.ShowDialog();
        }

        private void btnFacturas_Click(object sender, EventArgs e)
        {
            frmFacturas frm = new frmFacturas();
            frm.ShowDialog();
        }
        private void btnEmpleados_Click(object sender, EventArgs e)
        {
            if (this.pnlContenedor.Controls.Count > 0)
                this.pnlContenedor.Controls.RemoveAt(0);

            frmListaEmpleados frm = new frmListaEmpleados();
            frm.TopLevel = false;
            frm.FormBorderStyle = FormBorderStyle.None;
            frm.Dock = DockStyle.Fill;

            this.pnlContenedor.Controls.Add(frm);
            this.pnlContenedor.Tag = frm;
            frm.Show();
        }
        private void btnRoles_Click(object sender, EventArgs e)
        {
            frmRolEmpleados frm = new frmRolEmpleados();
            frm.ShowDialog();
        }
        private void btnSeguridad_Click(object sender, EventArgs e)
        {
            frmAdminSeguridad frm = new frmAdminSeguridad();
            frm.ShowDialog();
        }
        private void btnAyuda_Click(object sender, EventArgs e)
        {
            frmAyuda frm = new frmAyuda();
            frm.ShowDialog();
        }
        private void btnAcerca_de_Click(object sender, EventArgs e)
        {
            frmAcercaDe frm = new frmAcercaDe();
            frm.ShowDialog();
        }



        ///__________________________________________________________________________________
      
        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {

        }
    }
}
