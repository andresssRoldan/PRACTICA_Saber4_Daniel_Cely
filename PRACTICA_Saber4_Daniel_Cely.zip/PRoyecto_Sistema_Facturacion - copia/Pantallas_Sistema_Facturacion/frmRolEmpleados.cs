﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MaterialSkin;
using MaterialSkin.Controls;

namespace Pantallas_Sistema_Facturacion
{
    public partial class frmRolEmpleados : MaterialForm
    {
        public frmRolEmpleados()
        {
            InitializeComponent();
        }
        // -- *************************************************************************** --//
        private bool ValidarCampos()
        {
            bool esValido = true;
            errorProvider1.Clear();

            if (string.IsNullOrWhiteSpace(txtNombreRol_frmRolEmpleados.Text))
            {
                errorProvider1.SetError(txtNombreRol_frmRolEmpleados, "El campo Nombre del Rol es obligatorio.");
                esValido = false;
            }
            if (string.IsNullOrWhiteSpace(txtDescripcionRol_frmRolEmpleados.Text))
            {
                errorProvider1.SetError(txtDescripcionRol_frmRolEmpleados, "El campo Descripción del Rol es obligatorio.");
                esValido = false;
            }
            return esValido;
        }
            private void frmRolEmpleados_Load(object sender, EventArgs e)
        {
            
        }
        
        private void btnActualizar_frmRolEmpleados_Click(object sender, EventArgs e)
        {
            if (!ValidarCampos())
            {
                MessageBox.Show("Por favor, complete todos los campos obligatorios indicados.",
                                "Validación de datos",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
                return;
            }

            MessageBox.Show("Rol de empleado actualizado correctamente.",
                            "Gestión de Roles",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
        }

        // Evento Click para el botón Salir
        private void btnSalir_frmRolEmpleados_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
    
}
