﻿namespace Pantallas_Sistema_Facturacion
{
    partial class frmAdminSeguridad
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblTitulo_frmAdminSeguridad = new MaterialSkin.Controls.MaterialLabel();
            this.lblEmpleado_frmAdminSeguridad = new MaterialSkin.Controls.MaterialLabel();
            this.cboEmpleado_frmAdminSeguridad = new System.Windows.Forms.ComboBox();
            this.txtUsuario_frmAdminSeguridad = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.txtClave_frmAdminSeguridad = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.btnActualizar_frmAdminSeguridad = new MaterialSkin.Controls.MaterialRaisedButton();
            this.btnSalir_frmAdminSeguridad = new MaterialSkin.Controls.MaterialRaisedButton();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTitulo_frmAdminSeguridad
            // 
            this.lblTitulo_frmAdminSeguridad.AutoSize = true;
            this.lblTitulo_frmAdminSeguridad.Depth = 0;
            this.lblTitulo_frmAdminSeguridad.Font = new System.Drawing.Font("Roboto", 11F);
            this.lblTitulo_frmAdminSeguridad.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblTitulo_frmAdminSeguridad.Location = new System.Drawing.Point(130, 85);
            this.lblTitulo_frmAdminSeguridad.MouseState = MaterialSkin.MouseState.HOVER;
            this.lblTitulo_frmAdminSeguridad.Name = "lblTitulo_frmAdminSeguridad";
            this.lblTitulo_frmAdminSeguridad.Size = new System.Drawing.Size(329, 19);
            this.lblTitulo_frmAdminSeguridad.TabIndex = 0;
            this.lblTitulo_frmAdminSeguridad.Text = "ADMINISTRACIÓN DE USUARIOS DEL SISTEMA";
            // 
            // lblEmpleado_frmAdminSeguridad
            // 
            this.lblEmpleado_frmAdminSeguridad.AutoSize = true;
            this.lblEmpleado_frmAdminSeguridad.Depth = 0;
            this.lblEmpleado_frmAdminSeguridad.Font = new System.Drawing.Font("Roboto", 11F);
            this.lblEmpleado_frmAdminSeguridad.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblEmpleado_frmAdminSeguridad.Location = new System.Drawing.Point(50, 138);
            this.lblEmpleado_frmAdminSeguridad.MouseState = MaterialSkin.MouseState.HOVER;
            this.lblEmpleado_frmAdminSeguridad.Name = "lblEmpleado_frmAdminSeguridad";
            this.lblEmpleado_frmAdminSeguridad.Size = new System.Drawing.Size(76, 19);
            this.lblEmpleado_frmAdminSeguridad.TabIndex = 1;
            this.lblEmpleado_frmAdminSeguridad.Text = "Empleado";
            // 
            // cboEmpleado_frmAdminSeguridad
            // 
            this.cboEmpleado_frmAdminSeguridad.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboEmpleado_frmAdminSeguridad.FormattingEnabled = true;
            this.cboEmpleado_frmAdminSeguridad.Location = new System.Drawing.Point(145, 137);
            this.cboEmpleado_frmAdminSeguridad.Name = "cboEmpleado_frmAdminSeguridad";
            this.cboEmpleado_frmAdminSeguridad.Size = new System.Drawing.Size(310, 21);
            this.cboEmpleado_frmAdminSeguridad.TabIndex = 2;
            // 
            // txtUsuario_frmAdminSeguridad
            // 
            this.txtUsuario_frmAdminSeguridad.Depth = 0;
            this.txtUsuario_frmAdminSeguridad.Hint = "Usuario";
            this.txtUsuario_frmAdminSeguridad.Location = new System.Drawing.Point(145, 185);
            this.txtUsuario_frmAdminSeguridad.MouseState = MaterialSkin.MouseState.HOVER;
            this.txtUsuario_frmAdminSeguridad.Name = "txtUsuario_frmAdminSeguridad";
            this.txtUsuario_frmAdminSeguridad.PasswordChar = '\0';
            this.txtUsuario_frmAdminSeguridad.SelectedText = "";
            this.txtUsuario_frmAdminSeguridad.SelectionLength = 0;
            this.txtUsuario_frmAdminSeguridad.SelectionStart = 0;
            this.txtUsuario_frmAdminSeguridad.Size = new System.Drawing.Size(250, 23);
            this.txtUsuario_frmAdminSeguridad.TabIndex = 3;
            this.txtUsuario_frmAdminSeguridad.UseSystemPasswordChar = false;
            // 
            // txtClave_frmAdminSeguridad
            // 
            this.txtClave_frmAdminSeguridad.Depth = 0;
            this.txtClave_frmAdminSeguridad.Hint = "Clave";
            this.txtClave_frmAdminSeguridad.Location = new System.Drawing.Point(145, 230);
            this.txtClave_frmAdminSeguridad.MouseState = MaterialSkin.MouseState.HOVER;
            this.txtClave_frmAdminSeguridad.Name = "txtClave_frmAdminSeguridad";
            this.txtClave_frmAdminSeguridad.PasswordChar = '*';
            this.txtClave_frmAdminSeguridad.SelectedText = "";
            this.txtClave_frmAdminSeguridad.SelectionLength = 0;
            this.txtClave_frmAdminSeguridad.SelectionStart = 0;
            this.txtClave_frmAdminSeguridad.Size = new System.Drawing.Size(250, 23);
            this.txtClave_frmAdminSeguridad.TabIndex = 4;
            this.txtClave_frmAdminSeguridad.UseSystemPasswordChar = true;
            // 
            // btnActualizar_frmAdminSeguridad
            // 
            this.btnActualizar_frmAdminSeguridad.Depth = 0;
            this.btnActualizar_frmAdminSeguridad.Location = new System.Drawing.Point(140, 290);
            this.btnActualizar_frmAdminSeguridad.MouseState = MaterialSkin.MouseState.HOVER;
            this.btnActualizar_frmAdminSeguridad.Name = "btnActualizar_frmAdminSeguridad";
            this.btnActualizar_frmAdminSeguridad.Primary = true;
            this.btnActualizar_frmAdminSeguridad.Size = new System.Drawing.Size(130, 35);
            this.btnActualizar_frmAdminSeguridad.TabIndex = 5;
            this.btnActualizar_frmAdminSeguridad.Text = "ACTUALIZAR";
            this.btnActualizar_frmAdminSeguridad.UseVisualStyleBackColor = true;
            this.btnActualizar_frmAdminSeguridad.Click += new System.EventHandler(this.btnActualizar_frmAdminSeguridad_Click);
            // 
            // btnSalir_frmAdminSeguridad
            // 
            this.btnSalir_frmAdminSeguridad.Depth = 0;
            this.btnSalir_frmAdminSeguridad.Location = new System.Drawing.Point(290, 290);
            this.btnSalir_frmAdminSeguridad.MouseState = MaterialSkin.MouseState.HOVER;
            this.btnSalir_frmAdminSeguridad.Name = "btnSalir_frmAdminSeguridad";
            this.btnSalir_frmAdminSeguridad.Primary = true;
            this.btnSalir_frmAdminSeguridad.Size = new System.Drawing.Size(110, 35);
            this.btnSalir_frmAdminSeguridad.TabIndex = 6;
            this.btnSalir_frmAdminSeguridad.Text = "SALIR";
            this.btnSalir_frmAdminSeguridad.UseVisualStyleBackColor = true;
            this.btnSalir_frmAdminSeguridad.Click += new System.EventHandler(this.btnSalir_frmAdminSeguridad_Click);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // frmAdminSeguridad
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(510, 360);
            this.Controls.Add(this.btnSalir_frmAdminSeguridad);
            this.Controls.Add(this.btnActualizar_frmAdminSeguridad);
            this.Controls.Add(this.txtClave_frmAdminSeguridad);
            this.Controls.Add(this.txtUsuario_frmAdminSeguridad);
            this.Controls.Add(this.cboEmpleado_frmAdminSeguridad);
            this.Controls.Add(this.lblEmpleado_frmAdminSeguridad);
            this.Controls.Add(this.lblTitulo_frmAdminSeguridad);
            this.Name = "frmAdminSeguridad";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Administración de Seguridad";
            this.Load += new System.EventHandler(this.frmAdminSeguridad_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MaterialSkin.Controls.MaterialLabel lblTitulo_frmAdminSeguridad;
        private MaterialSkin.Controls.MaterialLabel lblEmpleado_frmAdminSeguridad;
        private System.Windows.Forms.ComboBox cboEmpleado_frmAdminSeguridad;
        private MaterialSkin.Controls.MaterialSingleLineTextField txtUsuario_frmAdminSeguridad;
        private MaterialSkin.Controls.MaterialSingleLineTextField txtClave_frmAdminSeguridad;
        private MaterialSkin.Controls.MaterialRaisedButton btnActualizar_frmAdminSeguridad;
        private MaterialSkin.Controls.MaterialRaisedButton btnSalir_frmAdminSeguridad;
        private System.Windows.Forms.ErrorProvider errorProvider1;
    }
}