﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MaterialSkin;
using MaterialSkin.Controls;

namespace Pantallas_Sistema_Facturacion
{
    public partial class frmListaEmpleados : MaterialForm
    {   
        acceso_Datos acceso = new acceso_Datos();
        public frmListaEmpleados()
        {
            InitializeComponent();
        }

        private void frmListaEmpleados_Load(object sender, EventArgs e)
        {
            CargarEmpleados(); // Metodo para cargar los empleados en el DataGridView al cargar el formulario
        }
        // ---------------------------------------------------------------- METODO PARA CARGAR EMPLEADOS EN EL DATAGRIDVIEW --------------------------------------------- //
        public void CargarEmpleados(string filtro = "")
        {
            try
            {
                string condicion = "";
                
                if (!string.IsNullOrWhiteSpace(filtro))
                {
                    condicion = $"WHERE StrNombre LIKE '%{filtro}%' OR NumDocumento LIKE '%{filtro}%'";
                }

                // Usamos el método 'cargarTabla' de acceso_Datos 
                DataTable dt = acceso.cargarTabla("TBLEMPLEADO", condicion);

                dgvEmpleados.AutoGenerateColumns = false;

                // VINCULO LAS COLUMNAS a mostrar con las propiedades del DataTable
                if (dgvEmpleados.Columns.Contains("ID")) dgvEmpleados.Columns["ID"].DataPropertyName = "IdEmpleado";
                if (dgvEmpleados.Columns.Contains("Nombre")) dgvEmpleados.Columns["Nombre"].DataPropertyName = "strNombre";
                if (dgvEmpleados.Columns.Contains("Documento")) dgvEmpleados.Columns["Documento"].DataPropertyName = "NumDocumento";
                if (dgvEmpleados.Columns.Contains("Telefono")) dgvEmpleados.Columns["Telefono"].DataPropertyName = "StrTelefono";

                // Asignamos la tabla de datos devuelta al DataGridView
                dgvEmpleados.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al consultar la lista de empleados: " + ex.Message,
                                "Error de Base de Datos",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
            }
        }

        // -------------------------------------------------Evento que se dispara cada vez que el usuario escribe una letra en el buscador ---------------------//
        private void txtBuscar_TextChanged(object sender, EventArgs e)
        {
            CargarEmpleados(txtBuscar.Text.Trim());
        }


        // --------------------------------------------------------------- Evento que se dispara al hacer click en editar o borrar  --------------------------------------------------------------- //
        private void dgvEmpleados_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Valido que el clic no sea en el encabezado
            if (e.RowIndex < 0) return;

            // Clic en el botón Editar del gfrid
            if (dgvEmpleados.Columns[e.ColumnIndex].Name == "colEditar")
            {
                int idEmpleado = Convert.ToInt32(dgvEmpleados.Rows[e.RowIndex].Cells["colId"].Value);

                frmEmpleados empleadoForm = new frmEmpleados(idEmpleado);

                if (empleadoForm.ShowDialog() == DialogResult.OK)
                {
                    CargarEmpleados(); // Refrescamos los cambios
                }
            }

            // Clic al  botón borrar de la grilla
            if (dgvEmpleados.Columns[e.ColumnIndex].Name == "colBorrar")
            {
                int idEmpleado = Convert.ToInt32(dgvEmpleados.Rows[e.RowIndex].Cells["colId"].Value);
                string nombre = dgvEmpleados.Rows[e.RowIndex].Cells["strNombre"].Value.ToString();

                DialogResult result = MessageBox.Show($"¿Está seguro de eliminar al empleado '{nombre}'?",
                                                      "Confirmar Eliminación",
                                                      MessageBoxButtons.YesNo,
                                                      MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    string sentencia = $"EXEC Eliminar_Empleado {idEmpleado}";
                    string respuesta = acceso.EjecutarComando(sentencia);

                    MessageBox.Show(respuesta, "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    CargarEmpleados();
                }
            }
        }
        // --------------------------------------------------------------- Boton Nuevo Empleado --------------------------------------------------------------- //
        private void btnNuevo_Click(object sender, EventArgs e)
        {
            // Le pasamos 0 al constructor para indicar que es un registro NUEVO
            frmEmpleados frm = new frmEmpleados(0);

            // ShowDialog() detiene la ejecución aquí hasta que la ventana modal se cierre
            if (frm.ShowDialog() == DialogResult.OK)
            {
                CargarEmpleados(); // Si guardó correctamente, refrescamos la grilla
            }
        }

        
        // --------------------------------------------------------------- Boton Salir --------------------------------------------------------------- //

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

       
    }
}
