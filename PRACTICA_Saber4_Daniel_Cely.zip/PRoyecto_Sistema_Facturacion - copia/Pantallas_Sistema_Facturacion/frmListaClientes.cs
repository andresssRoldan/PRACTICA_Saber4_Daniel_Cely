﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MaterialSkin;
using MaterialSkin.Controls;

namespace Pantallas_Sistema_Facturacion
{
    public partial class frmListaClientes : MaterialForm
    {

        // -------------------------------------- Istancia de la clase acceso_Datos para poder utilizar sus métodos
        acceso_Datos acceso = new acceso_Datos();
        public frmListaClientes()
        {
            InitializeComponent();
        }

        private void frmListaClientes_Load(object sender, EventArgs e)
        {
            llenar_grid();
        }
        // ----------------------------------------------------------- Metodo para llenar la tabla --------------------------//
        public void llenar_grid(string filtro = "")
        {
            string condicion = "";

            if (!string.IsNullOrEmpty(filtro))
            {
                condicion = "WHERE StrNombre LIKE '%" + filtro + "%' OR CAST(NumDocumento AS VARCHAR) LIKE '%" + filtro + "%'";
            }

            DataTable dt = acceso.cargarTabla("TBLCLIENTES", condicion);

            // Evita la duplicación de columnas
            dgvClientes.AutoGenerateColumns = false;

            // Asignación directa por el nombre de columna del diseñador
            dgvClientes.Columns["ID"].DataPropertyName = "IdCliente";
            dgvClientes.Columns["Cliente"].DataPropertyName = "StrNombre";
            dgvClientes.Columns["Documento"].DataPropertyName = "NumDocumento";
            dgvClientes.Columns["Telefono"].DataPropertyName = "StrTelefono";

            dgvClientes.DataSource = dt;
        }
        // -------------------------------------------------------------- CONFIGURACION EL BOTON DE BUSCAR ---------------------------------//
        private void btnBuscar_Click(object sender, EventArgs e)
        {
            llenar_grid(txtBuscar.Text.Trim());
        }

        // -------------------------------------------------------------- CONFIGURACION EL BOTON DE NUEVO ---------------------------------//
        private void btnNuevo_Click(object sender, EventArgs e)
        {
            frmClientes clientes = new frmClientes();
            clientes.idCliente = 0; 
            clientes.ShowDialog();
            llenar_grid(); 
        }

        // -------------------------------------------------------------- CONFIGURACION EL BOTON DE EDITAR Y BORRAR ---------------------------------//

        private void dgvClientes_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
            if (e.RowIndex < 0) return;

            // Obtener el nombre de la columna en la que se hizo clic
            string colNombre = dgvClientes.Columns[e.ColumnIndex].Name;
            string colHeader = dgvClientes.Columns[e.ColumnIndex].HeaderText;

            // ------------------------------------------------ Si se  hizo clic en la columna EDITAR (o si el HeaderText es "EDITAR")
            if (colNombre == "Editar")
            {
                int id = Convert.ToInt32(dgvClientes.Rows[e.RowIndex].Cells["ID"].Value);

                frmClientes frm = new frmClientes();
                frm.idCliente = id;
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    llenar_grid();
                }
            }

            // ----------------------------------------------- si se hace click  para Borrar
            if (colNombre == "Borrar")
            {
                int id = Convert.ToInt32(dgvClientes.Rows[e.RowIndex].Cells["ID"].Value);

                if (MessageBox.Show("¿Está seguro de eliminar este cliente?", "Confirmar eliminación", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    // Cambiamos 'idCliente' a 'IdCliente' para coincidir con SQL Server
                    string sql = "DELETE FROM TBLCLIENTES WHERE IdCliente = " + id;

                    // Guardamos y mostramos la respuesta de la base de datos
                    string respuesta = acceso.EjecutarComando(sql);
                    MessageBox.Show(respuesta, "Resultado de eliminación", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    // Recargamos la grilla
                    llenar_grid();
                }
            }
        }

        private void btnSalirListaClientes_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
