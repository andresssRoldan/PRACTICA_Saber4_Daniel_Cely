﻿namespace Pantallas_Sistema_Facturacion
{
    partial class frmRolEmpleados
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblTitulo_frmRolEmpleados = new MaterialSkin.Controls.MaterialLabel();
            this.txtNombreRol_frmRolEmpleados = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.lblDescripcionRol_frmRolEmpleados = new MaterialSkin.Controls.MaterialLabel();
            this.txtDescripcionRol_frmRolEmpleados = new System.Windows.Forms.TextBox();
            this.btnActualizar_frmRolEmpleados = new MaterialSkin.Controls.MaterialRaisedButton();
            this.btnSalir_frmRolEmpleados = new MaterialSkin.Controls.MaterialRaisedButton();
            this.txtBoxIdRolEmpleados = new System.Windows.Forms.TextBox();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTitulo_frmRolEmpleados
            // 
            this.lblTitulo_frmRolEmpleados.AutoSize = true;
            this.lblTitulo_frmRolEmpleados.Depth = 0;
            this.lblTitulo_frmRolEmpleados.Font = new System.Drawing.Font("Roboto", 11F);
            this.lblTitulo_frmRolEmpleados.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblTitulo_frmRolEmpleados.Location = new System.Drawing.Point(180, 85);
            this.lblTitulo_frmRolEmpleados.MouseState = MaterialSkin.MouseState.HOVER;
            this.lblTitulo_frmRolEmpleados.Name = "lblTitulo_frmRolEmpleados";
            this.lblTitulo_frmRolEmpleados.Size = new System.Drawing.Size(150, 19);
            this.lblTitulo_frmRolEmpleados.TabIndex = 0;
            this.lblTitulo_frmRolEmpleados.Text = "ROL DE EMPLEADOS";
            // 
            // txtNombreRol_frmRolEmpleados
            // 
            this.txtNombreRol_frmRolEmpleados.Depth = 0;
            this.txtNombreRol_frmRolEmpleados.Hint = "Nombre Rol";
            this.txtNombreRol_frmRolEmpleados.Location = new System.Drawing.Point(60, 135);
            this.txtNombreRol_frmRolEmpleados.MouseState = MaterialSkin.MouseState.HOVER;
            this.txtNombreRol_frmRolEmpleados.Name = "txtNombreRol_frmRolEmpleados";
            this.txtNombreRol_frmRolEmpleados.PasswordChar = '\0';
            this.txtNombreRol_frmRolEmpleados.SelectedText = "";
            this.txtNombreRol_frmRolEmpleados.SelectionLength = 0;
            this.txtNombreRol_frmRolEmpleados.SelectionStart = 0;
            this.txtNombreRol_frmRolEmpleados.Size = new System.Drawing.Size(380, 23);
            this.txtNombreRol_frmRolEmpleados.TabIndex = 1;
            this.txtNombreRol_frmRolEmpleados.UseSystemPasswordChar = false;
            // 
            // lblDescripcionRol_frmRolEmpleados
            // 
            this.lblDescripcionRol_frmRolEmpleados.AutoSize = true;
            this.lblDescripcionRol_frmRolEmpleados.Depth = 0;
            this.lblDescripcionRol_frmRolEmpleados.Font = new System.Drawing.Font("Roboto", 11F);
            this.lblDescripcionRol_frmRolEmpleados.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblDescripcionRol_frmRolEmpleados.Location = new System.Drawing.Point(60, 180);
            this.lblDescripcionRol_frmRolEmpleados.MouseState = MaterialSkin.MouseState.HOVER;
            this.lblDescripcionRol_frmRolEmpleados.Name = "lblDescripcionRol_frmRolEmpleados";
            this.lblDescripcionRol_frmRolEmpleados.Size = new System.Drawing.Size(180, 19);
            this.lblDescripcionRol_frmRolEmpleados.TabIndex = 2;
            this.lblDescripcionRol_frmRolEmpleados.Text = "Descripción detallada Rol";
            // 
            // txtDescripcionRol_frmRolEmpleados
            // 
            this.txtDescripcionRol_frmRolEmpleados.Location = new System.Drawing.Point(60, 205);
            this.txtDescripcionRol_frmRolEmpleados.Multiline = true;
            this.txtDescripcionRol_frmRolEmpleados.Name = "txtDescripcionRol_frmRolEmpleados";
            this.txtDescripcionRol_frmRolEmpleados.Size = new System.Drawing.Size(380, 80);
            this.txtDescripcionRol_frmRolEmpleados.TabIndex = 3;
            // 
            // btnActualizar_frmRolEmpleados
            // 
            this.btnActualizar_frmRolEmpleados.Depth = 0;
            this.btnActualizar_frmRolEmpleados.Location = new System.Drawing.Point(120, 315);
            this.btnActualizar_frmRolEmpleados.MouseState = MaterialSkin.MouseState.HOVER;
            this.btnActualizar_frmRolEmpleados.Name = "btnActualizar_frmRolEmpleados";
            this.btnActualizar_frmRolEmpleados.Primary = true;
            this.btnActualizar_frmRolEmpleados.Size = new System.Drawing.Size(91, 35);
            this.btnActualizar_frmRolEmpleados.TabIndex = 4;
            this.btnActualizar_frmRolEmpleados.Text = "ACTUALIZAR";
            this.btnActualizar_frmRolEmpleados.UseVisualStyleBackColor = true;
            this.btnActualizar_frmRolEmpleados.Click += new System.EventHandler(this.btnActualizar_frmRolEmpleados_Click);
            // 
            // btnSalir_frmRolEmpleados
            // 
            this.btnSalir_frmRolEmpleados.Depth = 0;
            this.btnSalir_frmRolEmpleados.Location = new System.Drawing.Point(270, 315);
            this.btnSalir_frmRolEmpleados.MouseState = MaterialSkin.MouseState.HOVER;
            this.btnSalir_frmRolEmpleados.Name = "btnSalir_frmRolEmpleados";
            this.btnSalir_frmRolEmpleados.Primary = true;
            this.btnSalir_frmRolEmpleados.Size = new System.Drawing.Size(110, 35);
            this.btnSalir_frmRolEmpleados.TabIndex = 5;
            this.btnSalir_frmRolEmpleados.Text = "SALIR";
            this.btnSalir_frmRolEmpleados.UseVisualStyleBackColor = true;
            this.btnSalir_frmRolEmpleados.Click += new System.EventHandler(this.btnSalir_frmRolEmpleados_Click);
            // 
            // txtBoxIdRolEmpleados
            // 
            this.txtBoxIdRolEmpleados.Location = new System.Drawing.Point(60, 109);
            this.txtBoxIdRolEmpleados.Name = "txtBoxIdRolEmpleados";
            this.txtBoxIdRolEmpleados.Size = new System.Drawing.Size(37, 20);
            this.txtBoxIdRolEmpleados.TabIndex = 7;
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // frmRolEmpleados
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(500, 380);
            this.Controls.Add(this.txtBoxIdRolEmpleados);
            this.Controls.Add(this.btnSalir_frmRolEmpleados);
            this.Controls.Add(this.btnActualizar_frmRolEmpleados);
            this.Controls.Add(this.txtDescripcionRol_frmRolEmpleados);
            this.Controls.Add(this.lblDescripcionRol_frmRolEmpleados);
            this.Controls.Add(this.txtNombreRol_frmRolEmpleados);
            this.Controls.Add(this.lblTitulo_frmRolEmpleados);
            this.Name = "frmRolEmpleados";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Rol Empleados";
            this.Load += new System.EventHandler(this.frmRolEmpleados_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MaterialSkin.Controls.MaterialLabel lblTitulo_frmRolEmpleados;
        private MaterialSkin.Controls.MaterialSingleLineTextField txtNombreRol_frmRolEmpleados;
        private MaterialSkin.Controls.MaterialLabel lblDescripcionRol_frmRolEmpleados;
        private System.Windows.Forms.TextBox txtDescripcionRol_frmRolEmpleados;
        private MaterialSkin.Controls.MaterialRaisedButton btnActualizar_frmRolEmpleados;
        private MaterialSkin.Controls.MaterialRaisedButton btnSalir_frmRolEmpleados;
        private System.Windows.Forms.TextBox txtBoxIdRolEmpleados;
        private System.Windows.Forms.ErrorProvider errorProvider1;
    }
}