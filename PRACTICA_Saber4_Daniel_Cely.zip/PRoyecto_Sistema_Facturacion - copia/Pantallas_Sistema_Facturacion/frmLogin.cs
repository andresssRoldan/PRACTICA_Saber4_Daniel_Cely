﻿using System;
using MaterialSkin;
using MaterialSkin.Controls;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pantallas_Sistema_Facturacion
{
    public partial class frmLogin : MaterialForm
    {
        // Instancia de la clase acceso_Datos para manejar la conexión a la base de datos
        acceso_Datos Acceso = new acceso_Datos();
        public frmLogin()
        {
            InitializeComponent();
        }

        // ------------------------------------------------ METODOS PARA LA CAPA DE PRESENTACION  --------------------------------------------- //

        private void ValidarIngreso()
        {
            // limpiamos errores previos con errorProvider1
            errorProvider1.Clear();

            // Validamos que el campo de usuario no esté vacío
            if (string.IsNullOrEmpty(txtUsuario.Text))
            {
                errorProvider1.SetError(txtUsuario, "El campo de usuario es obligatorio.");
                txtUsuario.Focus();
                return;
            }

            // Validamos que el campo de contraseña no esté vacío
            if (string.IsNullOrEmpty(txtPassword.Text))
            {
                errorProvider1.SetError(txtPassword, "El campo de contraseña es obligatorio.");
                txtPassword.Focus();
                return;
            }
            try
            {
                // Llamamos al metodo validarUsuario de la clase acceso_Datos para verificar las credenciales
                string strEmpleado = Acceso.validarUsuario(txtUsuario.Text, txtPassword.Text);
                // Si el resultado es vacío, significa que las credenciales son incorrectas
                if (string.IsNullOrEmpty(strEmpleado))
                {
                    MessageBox.Show("Usuario o contraseña incorrectos.", "Error de autenticación", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtUsuario.Clear();
                    txtPassword.Clear();
                    txtUsuario.Focus();
                }
                else
                {
                    // Si las credenciales son correctas, mostramos un mensaje de bienvenida y abrimos el formulario principal
                    MessageBox.Show($"Bienvenido {strEmpleado}!", "Autenticación exitosa", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Hide();
                    frmPrincipal principal = new frmPrincipal();
                    principal.ShowDialog();
                    this.Close();
                }

            }
            catch (Exception ex)
            {
                // En caso de error, mostramos un mensaje con la excepcion capturada
                MessageBox.Show($"Ocurrió un error al validar el usuario: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // ------------------------------------------------ EVENTOS DE LOS BOTONES --------------------------------------------- //
        
        private void frmLogin_Load(object sender, EventArgs e)
        {

        }
        private void btnIngresar_Click(object sender, EventArgs e)
        {
            ValidarIngreso();
        }
        private void btnCancelar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
