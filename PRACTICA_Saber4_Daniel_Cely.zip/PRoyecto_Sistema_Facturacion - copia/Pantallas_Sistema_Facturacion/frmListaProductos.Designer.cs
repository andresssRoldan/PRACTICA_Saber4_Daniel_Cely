﻿namespace Pantallas_Sistema_Facturacion
{
    partial class frmListaProductos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            this.materialLabel1 = new MaterialSkin.Controls.MaterialLabel();
            this.txtBuscar = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.btnBuscar = new MaterialSkin.Controls.MaterialRaisedButton();
            this.dgvProductos = new System.Windows.Forms.DataGridView();
            this.btnProductoNuevo = new MaterialSkin.Controls.MaterialRaisedButton();
            this.colId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCodigo = new System.Windows.Forms.DataGridViewButtonColumn();
            this.colProducto = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPrecioCompra = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colVenta = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCantidadStock = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colImagen = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDetalle = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEditar = new System.Windows.Forms.DataGridViewButtonColumn();
            this.colBorrar = new System.Windows.Forms.DataGridViewButtonColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProductos)).BeginInit();
            this.SuspendLayout();
            // 
            // materialLabel1
            // 
            this.materialLabel1.AutoSize = true;
            this.materialLabel1.Depth = 0;
            this.materialLabel1.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel1.Location = new System.Drawing.Point(299, 33);
            this.materialLabel1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel1.Name = "materialLabel1";
            this.materialLabel1.Size = new System.Drawing.Size(246, 19);
            this.materialLabel1.TabIndex = 6;
            this.materialLabel1.Text = "ADMINISTRACION DE PRODUCTOS";
            // 
            // txtBuscar
            // 
            this.txtBuscar.BackColor = System.Drawing.Color.White;
            this.txtBuscar.Depth = 0;
            this.txtBuscar.Hint = "Buscar";
            this.txtBuscar.Location = new System.Drawing.Point(12, 126);
            this.txtBuscar.MouseState = MaterialSkin.MouseState.HOVER;
            this.txtBuscar.Name = "txtBuscar";
            this.txtBuscar.PasswordChar = '\0';
            this.txtBuscar.SelectedText = "";
            this.txtBuscar.SelectionLength = 0;
            this.txtBuscar.SelectionStart = 0;
            this.txtBuscar.Size = new System.Drawing.Size(454, 23);
            this.txtBuscar.TabIndex = 7;
            this.txtBuscar.UseSystemPasswordChar = false;
            this.txtBuscar.Click += new System.EventHandler(this.txtBuscar_Click);
            this.txtBuscar.TextChanged += new System.EventHandler(this.txtBuscar_TextChanged);
            // 
            // btnBuscar
            // 
            this.btnBuscar.Depth = 0;
            this.btnBuscar.Location = new System.Drawing.Point(493, 126);
            this.btnBuscar.MouseState = MaterialSkin.MouseState.HOVER;
            this.btnBuscar.Name = "btnBuscar";
            this.btnBuscar.Primary = true;
            this.btnBuscar.Size = new System.Drawing.Size(83, 27);
            this.btnBuscar.TabIndex = 8;
            this.btnBuscar.Text = "Buscar";
            this.btnBuscar.UseVisualStyleBackColor = true;
            this.btnBuscar.Click += new System.EventHandler(this.btnBuscar_Click);
            // 
            // dgvProductos
            // 
            this.dgvProductos.AllowUserToAddRows = false;
            this.dgvProductos.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvProductos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvProductos.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colId,
            this.colCodigo,
            this.colProducto,
            this.colPrecioCompra,
            this.colVenta,
            this.colCantidadStock,
            this.colImagen,
            this.colDetalle,
            this.colEditar,
            this.colBorrar});
            this.dgvProductos.EnableHeadersVisualStyles = false;
            this.dgvProductos.Location = new System.Drawing.Point(12, 159);
            this.dgvProductos.Name = "dgvProductos";
            this.dgvProductos.Size = new System.Drawing.Size(890, 242);
            this.dgvProductos.TabIndex = 9;
            this.dgvProductos.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvProductos_CellContentClick);
            // 
            // btnProductoNuevo
            // 
            this.btnProductoNuevo.Depth = 0;
            this.btnProductoNuevo.Location = new System.Drawing.Point(750, 126);
            this.btnProductoNuevo.MouseState = MaterialSkin.MouseState.HOVER;
            this.btnProductoNuevo.Name = "btnProductoNuevo";
            this.btnProductoNuevo.Primary = true;
            this.btnProductoNuevo.Size = new System.Drawing.Size(78, 28);
            this.btnProductoNuevo.TabIndex = 10;
            this.btnProductoNuevo.Text = "Nuevo";
            this.btnProductoNuevo.UseVisualStyleBackColor = true;
            this.btnProductoNuevo.Click += new System.EventHandler(this.btnProductoNuevo_Click);
            // 
            // colId
            // 
            this.colId.DataPropertyName = "IdProducto";
            this.colId.HeaderText = "ID";
            this.colId.Name = "colId";
            this.colId.Visible = false;
            // 
            // colCodigo
            // 
            this.colCodigo.DataPropertyName = "StrCodigo";
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            this.colCodigo.DefaultCellStyle = dataGridViewCellStyle1;
            this.colCodigo.HeaderText = "CODIGO DE REFERENCIA";
            this.colCodigo.Name = "colCodigo";
            this.colCodigo.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colCodigo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // colProducto
            // 
            this.colProducto.DataPropertyName = "StrNombre";
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            this.colProducto.DefaultCellStyle = dataGridViewCellStyle2;
            this.colProducto.HeaderText = "PRODUCTO";
            this.colProducto.Name = "colProducto";
            // 
            // colPrecioCompra
            // 
            this.colPrecioCompra.DataPropertyName = "NumPrecioCompra";
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            this.colPrecioCompra.DefaultCellStyle = dataGridViewCellStyle3;
            this.colPrecioCompra.HeaderText = "PRECIO COMPRA";
            this.colPrecioCompra.Name = "colPrecioCompra";
            // 
            // colVenta
            // 
            this.colVenta.DataPropertyName = "NumPrecioVenta";
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            this.colVenta.DefaultCellStyle = dataGridViewCellStyle4;
            this.colVenta.HeaderText = "PRECIO VENTA";
            this.colVenta.Name = "colVenta";
            // 
            // colCantidadStock
            // 
            this.colCantidadStock.DataPropertyName = "numStock";
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.Black;
            this.colCantidadStock.DefaultCellStyle = dataGridViewCellStyle5;
            this.colCantidadStock.HeaderText = "CANTIDAD STOCK";
            this.colCantidadStock.Name = "colCantidadStock";
            this.colCantidadStock.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colCantidadStock.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colImagen
            // 
            this.colImagen.DataPropertyName = "strFoto";
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.Black;
            this.colImagen.DefaultCellStyle = dataGridViewCellStyle6;
            this.colImagen.HeaderText = "IMAGEN";
            this.colImagen.Name = "colImagen";
            this.colImagen.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colImagen.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colDetalle
            // 
            this.colDetalle.DataPropertyName = "StrDetalle";
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.Black;
            this.colDetalle.DefaultCellStyle = dataGridViewCellStyle7;
            this.colDetalle.HeaderText = "DETALLE";
            this.colDetalle.Name = "colDetalle";
            // 
            // colEditar
            // 
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.Transparent;
            this.colEditar.DefaultCellStyle = dataGridViewCellStyle8;
            this.colEditar.HeaderText = "EDITAR";
            this.colEditar.Name = "colEditar";
            this.colEditar.Text = "EDITAR";
            this.colEditar.UseColumnTextForButtonValue = true;
            // 
            // colBorrar
            // 
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.Black;
            this.colBorrar.DefaultCellStyle = dataGridViewCellStyle9;
            this.colBorrar.HeaderText = "BORRAR";
            this.colBorrar.Name = "colBorrar";
            this.colBorrar.Text = "BORRAR";
            this.colBorrar.UseColumnTextForButtonValue = true;
            // 
            // frmListaProductos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.ClientSize = new System.Drawing.Size(1009, 450);
            this.Controls.Add(this.btnProductoNuevo);
            this.Controls.Add(this.dgvProductos);
            this.Controls.Add(this.btnBuscar);
            this.Controls.Add(this.txtBuscar);
            this.Controls.Add(this.materialLabel1);
            this.Name = "frmListaProductos";
            this.Text = "CRUD LISTA PRODUCTOS";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmListaProductos_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvProductos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MaterialSkin.Controls.MaterialLabel materialLabel1;
        private MaterialSkin.Controls.MaterialSingleLineTextField txtBuscar;
        private MaterialSkin.Controls.MaterialRaisedButton btnBuscar;
        private System.Windows.Forms.DataGridView dgvProductos;
        private MaterialSkin.Controls.MaterialRaisedButton btnProductoNuevo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colId;
        private System.Windows.Forms.DataGridViewButtonColumn colCodigo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colProducto;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPrecioCompra;
        private System.Windows.Forms.DataGridViewTextBoxColumn colVenta;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCantidadStock;
        private System.Windows.Forms.DataGridViewTextBoxColumn colImagen;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDetalle;
        private System.Windows.Forms.DataGridViewButtonColumn colEditar;
        private System.Windows.Forms.DataGridViewButtonColumn colBorrar;
    }
}