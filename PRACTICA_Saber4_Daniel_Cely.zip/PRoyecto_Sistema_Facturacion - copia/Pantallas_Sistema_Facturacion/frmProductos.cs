﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using MaterialSkin;
using MaterialSkin.Controls;

namespace Pantallas_Sistema_Facturacion
{
    public partial class frmProductos : MaterialForm
    {
        acceso_Datos acceso = new acceso_Datos(); // Instancia de la clase acceso_Datos para acceder a la base de datos
        public int idProducto { get; set; } // Propiedad para almacenar el ID del producto seleccionado

        public frmProductos() // Constructor para NUEVO PRODUCTO
        {
            InitializeComponent();
            idProducto = 0; // 0 indica registro nuevo
        }

        public frmProductos(int id) // Constructor para EDITAR PRODUCTO
        {
            InitializeComponent();
            idProducto = id;
        }

        // -------------------------------------------------------- EVENTO LOAD DEL FORMULARIO -------------------------------------------------------------- //
        private void frmProductos_Load(object sender, EventArgs e)
        {
            CargarCategorias(); // Carga el ComboBox de categorías
            if (idProducto > 0) // Si el ID es mayor a 0, carga los datos para editar
            {
                CargarDatosProducto();
            }
        }

        // ------------------------------------------------------- METODO PARA CARGAR CATEGORIAS EN EL COMBOBOX --------------------------------------------- //
        private void CargarCategorias()
        {
            try
            {
                DataTable dt = acceso.cargarTabla("TBLCATEGORIA_PROD", "");
                comboBox1.DataSource = dt;
                comboBox1.DisplayMember = "StrDescripcion";
                comboBox1.ValueMember = "IdCategoria";
                comboBox1.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar las categorías: " + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // -------------------------------------------------------- METODO PARA CARGAR LOS DATOS DEL PRODUCTO -------------------------------------------------- //
        private void CargarDatosProducto()
        {
            try
            {
                DataTable dt = acceso.cargarTabla("TBLPRODUCTO", $"WHERE IdProducto = {idProducto}");

                if (dt.Rows.Count > 0)
                {
                    DataRow fila = dt.Rows[0];

                    mtlCodigoReferencia.Text = fila["StrCodigo"].ToString();
                    mtlNombreProducto.Text = fila["StrNombre"].ToString();
                    mtlPrecioCompra.Text = fila["NumPrecioCompra"].ToString();
                    mtlPrecioVenta.Text = fila["NumPrecioVenta"].ToString();
                    mtlCantidadStock.Text = fila["NumStock"].ToString();
                    textBox1.Text = fila["StrDetalle"].ToString();

                    if (fila["IdCategoria"] != DBNull.Value)
                    {
                        comboBox1.SelectedValue = Convert.ToInt32(fila["IdCategoria"]);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar datos del producto: " + ex.Message,
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // -------------------------------------------------------- EVENTO CLICK DEL BOTON ACTUALIZAR / GUARDAR -------------------------------------------------- //
        private void btnActualizarProductos_Click(object sender, EventArgs e)
        {
            try
            {
                // 1. Validar campos obligatorios del formulario
                if (string.IsNullOrWhiteSpace(mtlCodigoReferencia.Text) ||
                    string.IsNullOrWhiteSpace(mtlNombreProducto.Text) ||
                    string.IsNullOrWhiteSpace(mtlPrecioCompra.Text) ||
                    string.IsNullOrWhiteSpace(mtlPrecioVenta.Text) ||
                    string.IsNullOrWhiteSpace(mtlCantidadStock.Text) ||
                    comboBox1.SelectedValue == null)
                {
                    MessageBox.Show("Por favor complete todos los campos obligatorios.",
                                    "Campos Incompletos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // 2. Extraer y formatear variables
                string codigo = mtlCodigoReferencia.Text.Trim();
                string nombre = mtlNombreProducto.Text.Trim();
                decimal precioCompra = Convert.ToDecimal(mtlPrecioCompra.Text.Trim());
                decimal precioVenta = Convert.ToDecimal(mtlPrecioVenta.Text.Trim());
                int stock = Convert.ToInt32(mtlCantidadStock.Text.Trim());
                string rutaImagen = mtlRutaImagen.Text.Trim();
                string detalle = textBox1.Text.Trim();
                int idCategoria = Convert.ToInt32(comboBox1.SelectedValue);

                // Convertir decimales/floats usando punto (.) para SQL Server
                string strPrecioCompra = precioCompra.ToString(CultureInfo.InvariantCulture);
                string strPrecioVenta = precioVenta.ToString(CultureInfo.InvariantCulture);

                // Formato obligatorio de fecha para SQL Server (YYYY-MM-DD HH:MM:SS)
                string fechaActual = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                string usuarioModifica = "Admin"; // Puedes poner tu variable de usuario actual aquí

                string sentencia = "";

                if (idProducto > 0)
                {
                    // MODO EDICIÓN
                    sentencia = $@"UPDATE TBLPRODUCTO SET 
                    StrCodigo = '{codigo}', 
                    StrNombre = '{nombre}', 
                    NumPrecioCompra = {strPrecioCompra}, 
                    NumPrecioVenta = {strPrecioVenta}, 
                    NumStock = {stock}, 
                    strFoto = '{rutaImagen}',
                    StrDetalle = '{detalle}', 
                    IdCategoria = {idCategoria},
                    DtmFechaModifica = '{fechaActual}',
                    StrUsuarioModifica = '{usuarioModifica}'
                   WHERE IdProducto = {idProducto}";
                }
                else
                {
                    // MODO NUEVO 
                    sentencia = $@"INSERT INTO TBLPRODUCTO 
                    (StrNombre, StrCodigo, NumPrecioCompra, NumPrecioVenta, IdCategoria, StrDetalle, strFoto, NumStock, DtmFechaModifica, StrUsuarioModifica) 
                   VALUES 
                    ('{nombre}', '{codigo}', {strPrecioCompra}, {strPrecioVenta}, {idCategoria}, '{detalle}', '', {stock}, '{fechaActual}', '{usuarioModifica}')";
                }

                // 3. Ejecutar comando en la base de datos
                string respuesta = acceso.EjecutarComando(sentencia);

                MessageBox.Show("Operación realizada con éxito.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);

                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar los datos: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSalirProductos_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}