﻿namespace Pantallas_Sistema_Facturacion
{
    partial class frmAyuda
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        private void InitializeComponent()
        {
            this.webAyuda_frmAyuda = new System.Windows.Forms.WebBrowser();
            this.btnSalir_frmAyuda = new MaterialSkin.Controls.MaterialRaisedButton();
            this.SuspendLayout();
            // 
            // webAyuda_frmAyuda
            // 
            this.webAyuda_frmAyuda.Location = new System.Drawing.Point(15, 75);
            this.webAyuda_frmAyuda.MinimumSize = new System.Drawing.Size(20, 20);
            this.webAyuda_frmAyuda.Name = "webAyuda_frmAyuda";
            this.webAyuda_frmAyuda.Size = new System.Drawing.Size(770, 410);
            this.webAyuda_frmAyuda.TabIndex = 0;
            // 
            // btnSalir_frmAyuda
            // 
            this.btnSalir_frmAyuda.Depth = 0;
            this.btnSalir_frmAyuda.Location = new System.Drawing.Point(675, 500);
            this.btnSalir_frmAyuda.MouseState = MaterialSkin.MouseState.HOVER;
            this.btnSalir_frmAyuda.Name = "btnSalir_frmAyuda";
            this.btnSalir_frmAyuda.Primary = true;
            this.btnSalir_frmAyuda.Size = new System.Drawing.Size(110, 35);
            this.btnSalir_frmAyuda.TabIndex = 1;
            this.btnSalir_frmAyuda.Text = "SALIR";
            this.btnSalir_frmAyuda.UseVisualStyleBackColor = true;
            this.btnSalir_frmAyuda.Click += new System.EventHandler(this.btnSalir_frmAyuda_Click);
            // 
            // frmAyuda
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 550);
            this.Controls.Add(this.btnSalir_frmAyuda);
            this.Controls.Add(this.webAyuda_frmAyuda);
            this.Name = "frmAyuda";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ayuda del Sistema";
            this.Load += new System.EventHandler(this.frmAyuda_Load);
            this.ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.WebBrowser webAyuda_frmAyuda;
        private MaterialSkin.Controls.MaterialRaisedButton btnSalir_frmAyuda;
    }
}