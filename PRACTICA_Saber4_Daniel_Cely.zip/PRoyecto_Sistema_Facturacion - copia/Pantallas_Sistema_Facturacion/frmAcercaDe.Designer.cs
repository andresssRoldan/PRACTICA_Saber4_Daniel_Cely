﻿namespace Pantallas_Sistema_Facturacion
{
    partial class frmAcercaDe
    {
      
        private System.ComponentModel.IContainer components = null;

       
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAcercaDe));
            this.pnlContenedor_frmAcercaDe = new System.Windows.Forms.Panel();
            this.lblTitulo_frmAcercaDe = new System.Windows.Forms.Label();
            this.lblVersion_frmAcercaDe = new System.Windows.Forms.Label();
            this.lblDesarrolladores_frmAcercaDe = new System.Windows.Forms.Label();
            this.txtDescripcion_frmAcercaDe = new System.Windows.Forms.TextBox();
            this.btnSalir_frmAcercaDe = new MaterialSkin.Controls.MaterialRaisedButton();
            this.pnlContenedor_frmAcercaDe.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlContenedor_frmAcercaDe
            // 
            this.pnlContenedor_frmAcercaDe.BackColor = System.Drawing.Color.White;
            this.pnlContenedor_frmAcercaDe.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlContenedor_frmAcercaDe.Controls.Add(this.lblTitulo_frmAcercaDe);
            this.pnlContenedor_frmAcercaDe.Controls.Add(this.lblVersion_frmAcercaDe);
            this.pnlContenedor_frmAcercaDe.Controls.Add(this.lblDesarrolladores_frmAcercaDe);
            this.pnlContenedor_frmAcercaDe.Controls.Add(this.txtDescripcion_frmAcercaDe);
            this.pnlContenedor_frmAcercaDe.Controls.Add(this.btnSalir_frmAcercaDe);
            this.pnlContenedor_frmAcercaDe.Location = new System.Drawing.Point(15, 80);
            this.pnlContenedor_frmAcercaDe.Name = "pnlContenedor_frmAcercaDe";
            this.pnlContenedor_frmAcercaDe.Size = new System.Drawing.Size(570, 305);
            this.pnlContenedor_frmAcercaDe.TabIndex = 0;
            // 
            // lblTitulo_frmAcercaDe
            // 
            this.lblTitulo_frmAcercaDe.AutoSize = true;
            this.lblTitulo_frmAcercaDe.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.lblTitulo_frmAcercaDe.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(150)))), ((int)(((byte)(243)))));
            this.lblTitulo_frmAcercaDe.Location = new System.Drawing.Point(20, 15);
            this.lblTitulo_frmAcercaDe.Name = "lblTitulo_frmAcercaDe";
            this.lblTitulo_frmAcercaDe.Size = new System.Drawing.Size(327, 25);
            this.lblTitulo_frmAcercaDe.TabIndex = 0;
            this.lblTitulo_frmAcercaDe.Text = "Sistema de Facturación e Inventario";
            // 
            // lblVersion_frmAcercaDe
            // 
            this.lblVersion_frmAcercaDe.AutoSize = true;
            this.lblVersion_frmAcercaDe.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.lblVersion_frmAcercaDe.ForeColor = System.Drawing.Color.DimGray;
            this.lblVersion_frmAcercaDe.Location = new System.Drawing.Point(22, 45);
            this.lblVersion_frmAcercaDe.Name = "lblVersion_frmAcercaDe";
            this.lblVersion_frmAcercaDe.Size = new System.Drawing.Size(169, 17);
            this.lblVersion_frmAcercaDe.TabIndex = 1;
            this.lblVersion_frmAcercaDe.Text = "Versión: 1.0.0 (Build 2026)";
            // 
            // lblDesarrolladores_frmAcercaDe
            // 
            this.lblDesarrolladores_frmAcercaDe.AutoSize = true;
            this.lblDesarrolladores_frmAcercaDe.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Italic);
            this.lblDesarrolladores_frmAcercaDe.ForeColor = System.Drawing.Color.Gray;
            this.lblDesarrolladores_frmAcercaDe.Location = new System.Drawing.Point(22, 65);
            this.lblDesarrolladores_frmAcercaDe.Name = "lblDesarrolladores_frmAcercaDe";
            this.lblDesarrolladores_frmAcercaDe.Size = new System.Drawing.Size(249, 15);
            this.lblDesarrolladores_frmAcercaDe.TabIndex = 2;
            this.lblDesarrolladores_frmAcercaDe.Text = "Desarrollado por: Daniel Cely Roldán y Equipo";
            // 
            // txtDescripcion_frmAcercaDe
            // 
            this.txtDescripcion_frmAcercaDe.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(245)))), ((int)(((byte)(245)))));
            this.txtDescripcion_frmAcercaDe.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtDescripcion_frmAcercaDe.Location = new System.Drawing.Point(25, 95);
            this.txtDescripcion_frmAcercaDe.Multiline = true;
            this.txtDescripcion_frmAcercaDe.Name = "txtDescripcion_frmAcercaDe";
            this.txtDescripcion_frmAcercaDe.ReadOnly = true;
            this.txtDescripcion_frmAcercaDe.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtDescripcion_frmAcercaDe.Size = new System.Drawing.Size(518, 145);
            this.txtDescripcion_frmAcercaDe.TabIndex = 3;
            this.txtDescripcion_frmAcercaDe.Text = resources.GetString("txtDescripcion_frmAcercaDe.Text");
            // 
            // btnSalir_frmAcercaDe
            // 
            this.btnSalir_frmAcercaDe.Depth = 0;
            this.btnSalir_frmAcercaDe.Location = new System.Drawing.Point(443, 255);
            this.btnSalir_frmAcercaDe.MouseState = MaterialSkin.MouseState.HOVER;
            this.btnSalir_frmAcercaDe.Name = "btnSalir_frmAcercaDe";
            this.btnSalir_frmAcercaDe.Primary = true;
            this.btnSalir_frmAcercaDe.Size = new System.Drawing.Size(100, 35);
            this.btnSalir_frmAcercaDe.TabIndex = 4;
            this.btnSalir_frmAcercaDe.Text = "SALIR";
            this.btnSalir_frmAcercaDe.UseVisualStyleBackColor = true;
            this.btnSalir_frmAcercaDe.Click += new System.EventHandler(this.btnSalir_frmAcercaDe_Click);
            // 
            // frmAcercaDe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 400);
            this.Controls.Add(this.pnlContenedor_frmAcercaDe);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmAcercaDe";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Acerca de del Sistema";
            this.pnlContenedor_frmAcercaDe.ResumeLayout(false);
            this.pnlContenedor_frmAcercaDe.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlContenedor_frmAcercaDe;
        private System.Windows.Forms.Label lblTitulo_frmAcercaDe;
        private System.Windows.Forms.Label lblVersion_frmAcercaDe;
        private System.Windows.Forms.Label lblDesarrolladores_frmAcercaDe;
        private System.Windows.Forms.TextBox txtDescripcion_frmAcercaDe;
        private MaterialSkin.Controls.MaterialRaisedButton btnSalir_frmAcercaDe;
    }
}