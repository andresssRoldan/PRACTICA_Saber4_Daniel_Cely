﻿namespace Pantallas_Sistema_Facturacion
{
    partial class frmProductos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mtlTitulo = new MaterialSkin.Controls.MaterialLabel();
            this.mtlCantidadStock = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.mtlPrecioVenta = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.mtlPrecioCompra = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.mtlCodigoReferencia = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.mtlNombreProducto = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.txtBoxIdProductos = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.mtlRutaImagen = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.mlblDetallesProducto = new MaterialSkin.Controls.MaterialLabel();
            this.mlblCategoría = new MaterialSkin.Controls.MaterialLabel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btnActualizarProductos = new MaterialSkin.Controls.MaterialRaisedButton();
            this.btnSalirProductos = new MaterialSkin.Controls.MaterialRaisedButton();
            this.SuspendLayout();
            // 
            // mtlTitulo
            // 
            this.mtlTitulo.AutoSize = true;
            this.mtlTitulo.Depth = 0;
            this.mtlTitulo.Font = new System.Drawing.Font("Roboto", 11F);
            this.mtlTitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.mtlTitulo.Location = new System.Drawing.Point(270, 23);
            this.mtlTitulo.MouseState = MaterialSkin.MouseState.HOVER;
            this.mtlTitulo.Name = "mtlTitulo";
            this.mtlTitulo.Size = new System.Drawing.Size(246, 19);
            this.mtlTitulo.TabIndex = 0;
            this.mtlTitulo.Text = "ADMINISTRACION DE PRODUCTOS";
            // 
            // mtlCantidadStock
            // 
            this.mtlCantidadStock.Depth = 0;
            this.mtlCantidadStock.Hint = "Cantidad Stock";
            this.mtlCantidadStock.Location = new System.Drawing.Point(131, 331);
            this.mtlCantidadStock.MouseState = MaterialSkin.MouseState.HOVER;
            this.mtlCantidadStock.Name = "mtlCantidadStock";
            this.mtlCantidadStock.PasswordChar = '\0';
            this.mtlCantidadStock.SelectedText = "";
            this.mtlCantidadStock.SelectionLength = 0;
            this.mtlCantidadStock.SelectionStart = 0;
            this.mtlCantidadStock.Size = new System.Drawing.Size(114, 23);
            this.mtlCantidadStock.TabIndex = 1;
            this.mtlCantidadStock.UseSystemPasswordChar = false;
            // 
            // mtlPrecioVenta
            // 
            this.mtlPrecioVenta.Depth = 0;
            this.mtlPrecioVenta.Hint = "Precion Venta";
            this.mtlPrecioVenta.Location = new System.Drawing.Point(131, 282);
            this.mtlPrecioVenta.MouseState = MaterialSkin.MouseState.HOVER;
            this.mtlPrecioVenta.Name = "mtlPrecioVenta";
            this.mtlPrecioVenta.PasswordChar = '\0';
            this.mtlPrecioVenta.SelectedText = "";
            this.mtlPrecioVenta.SelectionLength = 0;
            this.mtlPrecioVenta.SelectionStart = 0;
            this.mtlPrecioVenta.Size = new System.Drawing.Size(114, 23);
            this.mtlPrecioVenta.TabIndex = 2;
            this.mtlPrecioVenta.UseSystemPasswordChar = false;
            // 
            // mtlPrecioCompra
            // 
            this.mtlPrecioCompra.Depth = 0;
            this.mtlPrecioCompra.Hint = "Precio Compra";
            this.mtlPrecioCompra.Location = new System.Drawing.Point(131, 227);
            this.mtlPrecioCompra.MouseState = MaterialSkin.MouseState.HOVER;
            this.mtlPrecioCompra.Name = "mtlPrecioCompra";
            this.mtlPrecioCompra.PasswordChar = '\0';
            this.mtlPrecioCompra.SelectedText = "";
            this.mtlPrecioCompra.SelectionLength = 0;
            this.mtlPrecioCompra.SelectionStart = 0;
            this.mtlPrecioCompra.Size = new System.Drawing.Size(114, 23);
            this.mtlPrecioCompra.TabIndex = 3;
            this.mtlPrecioCompra.UseSystemPasswordChar = false;
            // 
            // mtlCodigoReferencia
            // 
            this.mtlCodigoReferencia.Depth = 0;
            this.mtlCodigoReferencia.Hint = "Código Referencia";
            this.mtlCodigoReferencia.Location = new System.Drawing.Point(131, 169);
            this.mtlCodigoReferencia.MouseState = MaterialSkin.MouseState.HOVER;
            this.mtlCodigoReferencia.Name = "mtlCodigoReferencia";
            this.mtlCodigoReferencia.PasswordChar = '\0';
            this.mtlCodigoReferencia.SelectedText = "";
            this.mtlCodigoReferencia.SelectionLength = 0;
            this.mtlCodigoReferencia.SelectionStart = 0;
            this.mtlCodigoReferencia.Size = new System.Drawing.Size(151, 23);
            this.mtlCodigoReferencia.TabIndex = 4;
            this.mtlCodigoReferencia.UseSystemPasswordChar = false;
            // 
            // mtlNombreProducto
            // 
            this.mtlNombreProducto.Depth = 0;
            this.mtlNombreProducto.Hint = "Nombre Producto";
            this.mtlNombreProducto.Location = new System.Drawing.Point(131, 116);
            this.mtlNombreProducto.MouseState = MaterialSkin.MouseState.HOVER;
            this.mtlNombreProducto.Name = "mtlNombreProducto";
            this.mtlNombreProducto.PasswordChar = '\0';
            this.mtlNombreProducto.SelectedText = "";
            this.mtlNombreProducto.SelectionLength = 0;
            this.mtlNombreProducto.SelectionStart = 0;
            this.mtlNombreProducto.Size = new System.Drawing.Size(134, 23);
            this.mtlNombreProducto.TabIndex = 5;
            this.mtlNombreProducto.UseSystemPasswordChar = false;
            // 
            // txtBoxIdProductos
            // 
            this.txtBoxIdProductos.Location = new System.Drawing.Point(131, 90);
            this.txtBoxIdProductos.Name = "txtBoxIdProductos";
            this.txtBoxIdProductos.Size = new System.Drawing.Size(37, 20);
            this.txtBoxIdProductos.TabIndex = 6;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(503, 116);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 7;
            // 
            // mtlRutaImagen
            // 
            this.mtlRutaImagen.Depth = 0;
            this.mtlRutaImagen.Hint = "Ruta Imagen";
            this.mtlRutaImagen.Location = new System.Drawing.Point(425, 169);
            this.mtlRutaImagen.MouseState = MaterialSkin.MouseState.HOVER;
            this.mtlRutaImagen.Name = "mtlRutaImagen";
            this.mtlRutaImagen.PasswordChar = '\0';
            this.mtlRutaImagen.SelectedText = "";
            this.mtlRutaImagen.SelectionLength = 0;
            this.mtlRutaImagen.SelectionStart = 0;
            this.mtlRutaImagen.Size = new System.Drawing.Size(131, 23);
            this.mtlRutaImagen.TabIndex = 11;
            this.mtlRutaImagen.UseSystemPasswordChar = false;
            // 
            // mlblDetallesProducto
            // 
            this.mlblDetallesProducto.AutoSize = true;
            this.mlblDetallesProducto.Depth = 0;
            this.mlblDetallesProducto.Font = new System.Drawing.Font("Roboto", 11F);
            this.mlblDetallesProducto.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.mlblDetallesProducto.Location = new System.Drawing.Point(427, 215);
            this.mlblDetallesProducto.MouseState = MaterialSkin.MouseState.HOVER;
            this.mlblDetallesProducto.Name = "mlblDetallesProducto";
            this.mlblDetallesProducto.Size = new System.Drawing.Size(129, 19);
            this.mlblDetallesProducto.TabIndex = 12;
            this.mlblDetallesProducto.Text = "Detalles Producto";
            // 
            // mlblCategoría
            // 
            this.mlblCategoría.AutoSize = true;
            this.mlblCategoría.Depth = 0;
            this.mlblCategoría.Font = new System.Drawing.Font("Roboto", 11F);
            this.mlblCategoría.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.mlblCategoría.Location = new System.Drawing.Point(427, 115);
            this.mlblCategoría.MouseState = MaterialSkin.MouseState.HOVER;
            this.mlblCategoría.Name = "mlblCategoría";
            this.mlblCategoría.Size = new System.Drawing.Size(74, 19);
            this.mlblCategoría.TabIndex = 13;
            this.mlblCategoría.Text = "Categoría";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(425, 247);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(199, 94);
            this.textBox1.TabIndex = 14;
            // 
            // btnActualizarProductos
            // 
            this.btnActualizarProductos.Depth = 0;
            this.btnActualizarProductos.Location = new System.Drawing.Point(219, 389);
            this.btnActualizarProductos.MouseState = MaterialSkin.MouseState.HOVER;
            this.btnActualizarProductos.Name = "btnActualizarProductos";
            this.btnActualizarProductos.Primary = true;
            this.btnActualizarProductos.Size = new System.Drawing.Size(100, 27);
            this.btnActualizarProductos.TabIndex = 15;
            this.btnActualizarProductos.Text = "ACTUALIZAR";
            this.btnActualizarProductos.UseVisualStyleBackColor = true;
            this.btnActualizarProductos.Click += new System.EventHandler(this.btnActualizarProductos_Click);
            // 
            // btnSalirProductos
            // 
            this.btnSalirProductos.Depth = 0;
            this.btnSalirProductos.Location = new System.Drawing.Point(416, 389);
            this.btnSalirProductos.MouseState = MaterialSkin.MouseState.HOVER;
            this.btnSalirProductos.Name = "btnSalirProductos";
            this.btnSalirProductos.Primary = true;
            this.btnSalirProductos.Size = new System.Drawing.Size(100, 27);
            this.btnSalirProductos.TabIndex = 16;
            this.btnSalirProductos.Text = "SALIR";
            this.btnSalirProductos.UseVisualStyleBackColor = true;
            this.btnSalirProductos.Click += new System.EventHandler(this.btnSalirProductos_Click);
            // 
            // frmProductos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnSalirProductos);
            this.Controls.Add(this.btnActualizarProductos);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.mlblCategoría);
            this.Controls.Add(this.mlblDetallesProducto);
            this.Controls.Add(this.mtlRutaImagen);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.txtBoxIdProductos);
            this.Controls.Add(this.mtlNombreProducto);
            this.Controls.Add(this.mtlCodigoReferencia);
            this.Controls.Add(this.mtlPrecioCompra);
            this.Controls.Add(this.mtlPrecioVenta);
            this.Controls.Add(this.mtlCantidadStock);
            this.Controls.Add(this.mtlTitulo);
            this.Name = "frmProductos";
            this.Load += new System.EventHandler(this.frmProductos_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MaterialSkin.Controls.MaterialLabel mtlTitulo;
        private MaterialSkin.Controls.MaterialSingleLineTextField mtlCantidadStock;
        private MaterialSkin.Controls.MaterialSingleLineTextField mtlPrecioVenta;
        private MaterialSkin.Controls.MaterialSingleLineTextField mtlPrecioCompra;
        private MaterialSkin.Controls.MaterialSingleLineTextField mtlCodigoReferencia;
        private MaterialSkin.Controls.MaterialSingleLineTextField mtlNombreProducto;
        private System.Windows.Forms.TextBox txtBoxIdProductos;
        private System.Windows.Forms.ComboBox comboBox1;
        private MaterialSkin.Controls.MaterialSingleLineTextField mtlRutaImagen;
        private MaterialSkin.Controls.MaterialLabel mlblDetallesProducto;
        private MaterialSkin.Controls.MaterialLabel mlblCategoría;
        private System.Windows.Forms.TextBox textBox1;
        private MaterialSkin.Controls.MaterialRaisedButton btnActualizarProductos;
        private MaterialSkin.Controls.MaterialRaisedButton btnSalirProductos;
    }
}