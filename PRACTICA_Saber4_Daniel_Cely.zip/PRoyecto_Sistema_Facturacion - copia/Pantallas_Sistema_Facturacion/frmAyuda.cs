﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MaterialSkin;
using MaterialSkin.Controls;

namespace Pantallas_Sistema_Facturacion
{
    public partial class frmAyuda : MaterialForm
    {
        public frmAyuda()
        {
            InitializeComponent();
        }

        private void frmAyuda_Load(object sender, EventArgs e)
        {
            // Silencia las alertas de error de JavaScript (causadas por el motor IE del WebBrowser)
            webAyuda_frmAyuda.ScriptErrorsSuppressed = true;

            // ASIGNACION DE LA  URL oficial de Microsoft indicada en el requerimiento
            webAyuda_frmAyuda.Navigate("https://docs.microsoft.com");
        }
        private void btnSalir_frmAyuda_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
