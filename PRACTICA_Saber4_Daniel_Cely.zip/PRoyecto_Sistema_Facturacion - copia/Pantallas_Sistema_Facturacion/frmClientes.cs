﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MaterialSkin;
using MaterialSkin.Controls;

namespace Pantallas_Sistema_Facturacion
{
    public partial class frmClientes : MaterialForm
    {
        public int idCliente { get; set; }
        // -------------------------------------- Istancia de la clase acceso_Datos para poder utilizar sus métodos ----------//
        acceso_Datos acceso = new acceso_Datos();
        public frmClientes()
        {
            InitializeComponent();
        }
        // ------------------------------------------------------ CONFIGURACION EVENTO LOAD DEL FORMULARIO ---------------------------------//

        private void frmClientes_Load(object sender, EventArgs e)
        {
            if(idCliente > 0)
            {
                DataTable dt = acceso.cargarTabla("TBLCLIENTES", "WHERE IdCliente = " + idCliente);
                if (dt != null && dt.Rows.Count > 0)
                {
                    DataRow row = dt.Rows[0];
                    txtNombre.Text = row["StrNombre"].ToString();
                    txtDocumento.Text = row["NumDocumento"].ToString();
                    txtDireccion.Text = row["StrDireccion"].ToString();
                    txtTelefono.Text = row["StrTelefono"].ToString();
                    txtEmail.Text = row["StrEmail"].ToString();
                }
            }
        }

        // -------------------------------------------------------------- CONFIGURACION EL BOTON DE GUARDAR ---------------------------------//
        private void btnAgregar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNombre.Text) || string.IsNullOrWhiteSpace(txtDocumento.Text))
            {
                MessageBox.Show("Por favor complete el nombre y el documento.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string sentencia = "";

            if (idCliente == 0)
            {
                // INSERT: Cambiamos StrDocumento por NumDocumento e incluimos fecha/usuario de modificación
                sentencia = $"INSERT INTO TBLCLIENTES (StrNombre, NumDocumento, StrDireccion, StrTelefono, StrEmail, DtmFechaModifica, StrUsuarioModifica) " +
                            $"VALUES ('{txtNombre.Text.Trim()}', {txtDocumento.Text.Trim()}, '{txtDireccion.Text.Trim()}', '{txtTelefono.Text.Trim()}', '{txtEmail.Text.Trim()}', GETDATE(), 'admin')";
            }
            else
            {
                // UPDATE: Cambiamos StrDocumento por NumDocumento
                sentencia = $"UPDATE TBLCLIENTES SET " +
                            $"StrNombre = '{txtNombre.Text.Trim()}', " +
                            $"NumDocumento = {txtDocumento.Text.Trim()}, " +
                            $"StrDireccion = '{txtDireccion.Text.Trim()}', " +
                            $"StrTelefono = '{txtTelefono.Text.Trim()}', " +
                            $"StrEmail = '{txtEmail.Text.Trim()}', " +
                            $"DtmFechaModifica = GETDATE(), " +
                            $"StrUsuarioModifica = 'admin' " +
                            $"WHERE IdCliente = {idCliente}";
            }

            string respuesta = acceso.EjecutarComando(sentencia);
            MessageBox.Show(respuesta, "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Information);

            this.DialogResult = DialogResult.OK;
            this.Close();
        }


        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

       
    }
}
