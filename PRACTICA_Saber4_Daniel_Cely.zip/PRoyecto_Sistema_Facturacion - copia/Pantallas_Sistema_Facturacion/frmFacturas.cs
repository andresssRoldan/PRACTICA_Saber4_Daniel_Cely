﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MaterialSkin;
using MaterialSkin.Controls;

namespace Pantallas_Sistema_Facturacion
{
    public partial class frmFacturas : MaterialForm
    {
        public frmFacturas()
        {
            InitializeComponent();
        }
        private bool ValidarCampos()
        {
            bool esValido = true;
            errorProvider1.Clear();

            // 1. numero de Factura
            if (string.IsNullOrWhiteSpace(txtNroFactura_frmFacturas.Text))
            {
                errorProvider1.SetError(txtNroFactura_frmFacturas, "El numero de factura es obligatorio.");
                esValido = false;
            }

            // 2. Cliente
            if (cboCliente_frmFacturas.SelectedIndex == -1 || string.IsNullOrWhiteSpace(cboCliente_frmFacturas.Text))
            {
                errorProvider1.SetError(cboCliente_frmFacturas, "Debe seleccionar un cliente.");
                esValido = false;
            }

            // 3. Empleado
            if (cboEmpleado_frmFacturas.SelectedIndex == -1 || string.IsNullOrWhiteSpace(cboEmpleado_frmFacturas.Text))
            {
                errorProvider1.SetError(cboEmpleado_frmFacturas, "Debe seleccionar un empleado.");
                esValido = false;
            }

            // 4. Descuento
            if (string.IsNullOrWhiteSpace(txtDescuento_frmFacturas.Text))
            {
                errorProvider1.SetError(txtDescuento_frmFacturas, "Ingrese el descuento.");
                esValido = false;
            }

            // 5. Total IVA
            if (string.IsNullOrWhiteSpace(txtTotalIva_frmFacturas.Text))
            {
                errorProvider1.SetError(txtTotalIva_frmFacturas, "El total IVA es obligatorio.");
                esValido = false;
            }

            // 6. Total Factura
            if (string.IsNullOrWhiteSpace(txtTotalFactura_frmFacturas.Text))
            {
                errorProvider1.SetError(txtTotalFactura_frmFacturas, "El total de la factura es obligatorio.");
                esValido = false;
            }

            // 7. Estado Factura
            if (cboEstadoFactura_frmFacturas.SelectedIndex == -1 || string.IsNullOrWhiteSpace(cboEstadoFactura_frmFacturas.Text))
            {
                errorProvider1.SetError(cboEstadoFactura_frmFacturas, "Debe seleccionar un estado.");
                esValido = false;
            }

            return esValido;
        }

       

        private void frmFacturas_Load(object sender, EventArgs e)
        {

        }

        private void btnSalir_frmFacturas_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnActualizar_frmFacturas_Click_1(object sender, EventArgs e)
        {
            if (!ValidarCampos())
            {
                MessageBox.Show("Por favor, complete los campos obligatorios indicados.",
                                "Validación de datos",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
                return;
            }

            MessageBox.Show("Factura actualizada con éxito.",
                            "Sistema de Facturación",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
        }

        private void frmFacturas_Load_1(object sender, EventArgs e)
        {

        }
    }
}
