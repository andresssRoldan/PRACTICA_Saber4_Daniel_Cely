﻿namespace Pantallas_Sistema_Facturacion
{
    partial class frmEmpleados
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblTitulo_frmEmpleados = new MaterialSkin.Controls.MaterialLabel();
            this.txtNombre_frmEmpleados = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.txtDocumento_frmEmpleados = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.txtDireccion_frmEmpleados = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.txtTelefono_frmEmpleados = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.txtEmail_frmEmpleados = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.lblRolEmpleado_frmEmpleados = new MaterialSkin.Controls.MaterialLabel();
            this.cboRol_frmEmpleados = new System.Windows.Forms.ComboBox();
            this.lblFIngreso_frmEmpleados = new MaterialSkin.Controls.MaterialLabel();
            this.dtpFechaIngreso_frmEmpleados = new System.Windows.Forms.DateTimePicker();
            this.lblFRetiro_frmEmpleados = new MaterialSkin.Controls.MaterialLabel();
            this.dtpFechaRetiro_frmEmpleados = new System.Windows.Forms.DateTimePicker();
            this.lblDatosAdicionales_frmEmpleados = new MaterialSkin.Controls.MaterialLabel();
            this.txtDatosAdicionales_frmEmpleados = new System.Windows.Forms.TextBox();
            this.btnActualizar_frmEmpleados = new MaterialSkin.Controls.MaterialRaisedButton();
            this.btnSalir_frmEmpleados = new MaterialSkin.Controls.MaterialRaisedButton();
            this.txtBoxIdEmpleados = new System.Windows.Forms.TextBox();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTitulo_frmEmpleados
            // 
            this.lblTitulo_frmEmpleados.AutoSize = true;
            this.lblTitulo_frmEmpleados.Depth = 0;
            this.lblTitulo_frmEmpleados.Font = new System.Drawing.Font("Roboto", 11F);
            this.lblTitulo_frmEmpleados.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblTitulo_frmEmpleados.Location = new System.Drawing.Point(220, 85);
            this.lblTitulo_frmEmpleados.MouseState = MaterialSkin.MouseState.HOVER;
            this.lblTitulo_frmEmpleados.Name = "lblTitulo_frmEmpleados";
            this.lblTitulo_frmEmpleados.Size = new System.Drawing.Size(247, 19);
            this.lblTitulo_frmEmpleados.TabIndex = 0;
            this.lblTitulo_frmEmpleados.Text = "ADMINISTRACIÓN DE EMPLEADOS";
            // 
            // txtNombre_frmEmpleados
            // 
            this.txtNombre_frmEmpleados.Depth = 0;
            this.txtNombre_frmEmpleados.Hint = "Nombre Empleado";
            this.txtNombre_frmEmpleados.Location = new System.Drawing.Point(40, 135);
            this.txtNombre_frmEmpleados.MouseState = MaterialSkin.MouseState.HOVER;
            this.txtNombre_frmEmpleados.Name = "txtNombre_frmEmpleados";
            this.txtNombre_frmEmpleados.PasswordChar = '\0';
            this.txtNombre_frmEmpleados.SelectedText = "";
            this.txtNombre_frmEmpleados.SelectionLength = 0;
            this.txtNombre_frmEmpleados.SelectionStart = 0;
            this.txtNombre_frmEmpleados.Size = new System.Drawing.Size(300, 23);
            this.txtNombre_frmEmpleados.TabIndex = 1;
            this.txtNombre_frmEmpleados.UseSystemPasswordChar = false;
            // 
            // txtDocumento_frmEmpleados
            // 
            this.txtDocumento_frmEmpleados.Depth = 0;
            this.txtDocumento_frmEmpleados.Hint = "Documento";
            this.txtDocumento_frmEmpleados.Location = new System.Drawing.Point(40, 175);
            this.txtDocumento_frmEmpleados.MouseState = MaterialSkin.MouseState.HOVER;
            this.txtDocumento_frmEmpleados.Name = "txtDocumento_frmEmpleados";
            this.txtDocumento_frmEmpleados.PasswordChar = '\0';
            this.txtDocumento_frmEmpleados.SelectedText = "";
            this.txtDocumento_frmEmpleados.SelectionLength = 0;
            this.txtDocumento_frmEmpleados.SelectionStart = 0;
            this.txtDocumento_frmEmpleados.Size = new System.Drawing.Size(300, 23);
            this.txtDocumento_frmEmpleados.TabIndex = 2;
            this.txtDocumento_frmEmpleados.UseSystemPasswordChar = false;
            // 
            // txtDireccion_frmEmpleados
            // 
            this.txtDireccion_frmEmpleados.Depth = 0;
            this.txtDireccion_frmEmpleados.Hint = "Dirección";
            this.txtDireccion_frmEmpleados.Location = new System.Drawing.Point(40, 215);
            this.txtDireccion_frmEmpleados.MouseState = MaterialSkin.MouseState.HOVER;
            this.txtDireccion_frmEmpleados.Name = "txtDireccion_frmEmpleados";
            this.txtDireccion_frmEmpleados.PasswordChar = '\0';
            this.txtDireccion_frmEmpleados.SelectedText = "";
            this.txtDireccion_frmEmpleados.SelectionLength = 0;
            this.txtDireccion_frmEmpleados.SelectionStart = 0;
            this.txtDireccion_frmEmpleados.Size = new System.Drawing.Size(300, 23);
            this.txtDireccion_frmEmpleados.TabIndex = 3;
            this.txtDireccion_frmEmpleados.UseSystemPasswordChar = false;
            // 
            // txtTelefono_frmEmpleados
            // 
            this.txtTelefono_frmEmpleados.Depth = 0;
            this.txtTelefono_frmEmpleados.Hint = "Teléfono";
            this.txtTelefono_frmEmpleados.Location = new System.Drawing.Point(40, 255);
            this.txtTelefono_frmEmpleados.MouseState = MaterialSkin.MouseState.HOVER;
            this.txtTelefono_frmEmpleados.Name = "txtTelefono_frmEmpleados";
            this.txtTelefono_frmEmpleados.PasswordChar = '\0';
            this.txtTelefono_frmEmpleados.SelectedText = "";
            this.txtTelefono_frmEmpleados.SelectionLength = 0;
            this.txtTelefono_frmEmpleados.SelectionStart = 0;
            this.txtTelefono_frmEmpleados.Size = new System.Drawing.Size(300, 23);
            this.txtTelefono_frmEmpleados.TabIndex = 4;
            this.txtTelefono_frmEmpleados.UseSystemPasswordChar = false;
            // 
            // txtEmail_frmEmpleados
            // 
            this.txtEmail_frmEmpleados.Depth = 0;
            this.txtEmail_frmEmpleados.Hint = "Email";
            this.txtEmail_frmEmpleados.Location = new System.Drawing.Point(40, 295);
            this.txtEmail_frmEmpleados.MouseState = MaterialSkin.MouseState.HOVER;
            this.txtEmail_frmEmpleados.Name = "txtEmail_frmEmpleados";
            this.txtEmail_frmEmpleados.PasswordChar = '\0';
            this.txtEmail_frmEmpleados.SelectedText = "";
            this.txtEmail_frmEmpleados.SelectionLength = 0;
            this.txtEmail_frmEmpleados.SelectionStart = 0;
            this.txtEmail_frmEmpleados.Size = new System.Drawing.Size(300, 23);
            this.txtEmail_frmEmpleados.TabIndex = 5;
            this.txtEmail_frmEmpleados.UseSystemPasswordChar = false;
            // 
            // lblRolEmpleado_frmEmpleados
            // 
            this.lblRolEmpleado_frmEmpleados.AutoSize = true;
            this.lblRolEmpleado_frmEmpleados.Depth = 0;
            this.lblRolEmpleado_frmEmpleados.Font = new System.Drawing.Font("Roboto", 11F);
            this.lblRolEmpleado_frmEmpleados.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblRolEmpleado_frmEmpleados.Location = new System.Drawing.Point(380, 135);
            this.lblRolEmpleado_frmEmpleados.MouseState = MaterialSkin.MouseState.HOVER;
            this.lblRolEmpleado_frmEmpleados.Name = "lblRolEmpleado_frmEmpleados";
            this.lblRolEmpleado_frmEmpleados.Size = new System.Drawing.Size(102, 19);
            this.lblRolEmpleado_frmEmpleados.TabIndex = 6;
            this.lblRolEmpleado_frmEmpleados.Text = "Rol Empleado";
            // 
            // cboRol_frmEmpleados
            // 
            this.cboRol_frmEmpleados.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboRol_frmEmpleados.FormattingEnabled = true;
            this.cboRol_frmEmpleados.Location = new System.Drawing.Point(490, 135);
            this.cboRol_frmEmpleados.Name = "cboRol_frmEmpleados";
            this.cboRol_frmEmpleados.Size = new System.Drawing.Size(160, 21);
            this.cboRol_frmEmpleados.TabIndex = 7;
            // 
            // lblFIngreso_frmEmpleados
            // 
            this.lblFIngreso_frmEmpleados.AutoSize = true;
            this.lblFIngreso_frmEmpleados.Depth = 0;
            this.lblFIngreso_frmEmpleados.Font = new System.Drawing.Font("Roboto", 11F);
            this.lblFIngreso_frmEmpleados.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblFIngreso_frmEmpleados.Location = new System.Drawing.Point(380, 175);
            this.lblFIngreso_frmEmpleados.MouseState = MaterialSkin.MouseState.HOVER;
            this.lblFIngreso_frmEmpleados.Name = "lblFIngreso_frmEmpleados";
            this.lblFIngreso_frmEmpleados.Size = new System.Drawing.Size(75, 19);
            this.lblFIngreso_frmEmpleados.TabIndex = 8;
            this.lblFIngreso_frmEmpleados.Text = "F. Ingreso";
            // 
            // dtpFechaIngreso_frmEmpleados
            // 
            this.dtpFechaIngreso_frmEmpleados.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFechaIngreso_frmEmpleados.Location = new System.Drawing.Point(490, 175);
            this.dtpFechaIngreso_frmEmpleados.Name = "dtpFechaIngreso_frmEmpleados";
            this.dtpFechaIngreso_frmEmpleados.Size = new System.Drawing.Size(160, 20);
            this.dtpFechaIngreso_frmEmpleados.TabIndex = 9;
            // 
            // lblFRetiro_frmEmpleados
            // 
            this.lblFRetiro_frmEmpleados.AutoSize = true;
            this.lblFRetiro_frmEmpleados.Depth = 0;
            this.lblFRetiro_frmEmpleados.Font = new System.Drawing.Font("Roboto", 11F);
            this.lblFRetiro_frmEmpleados.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblFRetiro_frmEmpleados.Location = new System.Drawing.Point(380, 215);
            this.lblFRetiro_frmEmpleados.MouseState = MaterialSkin.MouseState.HOVER;
            this.lblFRetiro_frmEmpleados.Name = "lblFRetiro_frmEmpleados";
            this.lblFRetiro_frmEmpleados.Size = new System.Drawing.Size(65, 19);
            this.lblFRetiro_frmEmpleados.TabIndex = 10;
            this.lblFRetiro_frmEmpleados.Text = "F. Retiro";
            // 
            // dtpFechaRetiro_frmEmpleados
            // 
            this.dtpFechaRetiro_frmEmpleados.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFechaRetiro_frmEmpleados.Location = new System.Drawing.Point(490, 215);
            this.dtpFechaRetiro_frmEmpleados.Name = "dtpFechaRetiro_frmEmpleados";
            this.dtpFechaRetiro_frmEmpleados.Size = new System.Drawing.Size(160, 20);
            this.dtpFechaRetiro_frmEmpleados.TabIndex = 11;
            // 
            // lblDatosAdicionales_frmEmpleados
            // 
            this.lblDatosAdicionales_frmEmpleados.AutoSize = true;
            this.lblDatosAdicionales_frmEmpleados.Depth = 0;
            this.lblDatosAdicionales_frmEmpleados.Font = new System.Drawing.Font("Roboto", 11F);
            this.lblDatosAdicionales_frmEmpleados.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblDatosAdicionales_frmEmpleados.Location = new System.Drawing.Point(380, 255);
            this.lblDatosAdicionales_frmEmpleados.MouseState = MaterialSkin.MouseState.HOVER;
            this.lblDatosAdicionales_frmEmpleados.Name = "lblDatosAdicionales_frmEmpleados";
            this.lblDatosAdicionales_frmEmpleados.Size = new System.Drawing.Size(156, 19);
            this.lblDatosAdicionales_frmEmpleados.TabIndex = 12;
            this.lblDatosAdicionales_frmEmpleados.Text = "DATOS ADICIONALES";
            // 
            // txtDatosAdicionales_frmEmpleados
            // 
            this.txtDatosAdicionales_frmEmpleados.Location = new System.Drawing.Point(380, 280);
            this.txtDatosAdicionales_frmEmpleados.Multiline = true;
            this.txtDatosAdicionales_frmEmpleados.Name = "txtDatosAdicionales_frmEmpleados";
            this.txtDatosAdicionales_frmEmpleados.Size = new System.Drawing.Size(270, 50);
            this.txtDatosAdicionales_frmEmpleados.TabIndex = 13;
            // 
            // btnActualizar_frmEmpleados
            // 
            this.btnActualizar_frmEmpleados.Depth = 0;
            this.btnActualizar_frmEmpleados.Location = new System.Drawing.Point(220, 360);
            this.btnActualizar_frmEmpleados.MouseState = MaterialSkin.MouseState.HOVER;
            this.btnActualizar_frmEmpleados.Name = "btnActualizar_frmEmpleados";
            this.btnActualizar_frmEmpleados.Primary = true;
            this.btnActualizar_frmEmpleados.Size = new System.Drawing.Size(130, 35);
            this.btnActualizar_frmEmpleados.TabIndex = 14;
            this.btnActualizar_frmEmpleados.Text = "ACTUALIZAR";
            this.btnActualizar_frmEmpleados.UseVisualStyleBackColor = true;
            this.btnActualizar_frmEmpleados.Click += new System.EventHandler(this.btnActualizar_frmEmpleados_Click);
            // 
            // btnSalir_frmEmpleados
            // 
            this.btnSalir_frmEmpleados.Depth = 0;
            this.btnSalir_frmEmpleados.Location = new System.Drawing.Point(370, 360);
            this.btnSalir_frmEmpleados.MouseState = MaterialSkin.MouseState.HOVER;
            this.btnSalir_frmEmpleados.Name = "btnSalir_frmEmpleados";
            this.btnSalir_frmEmpleados.Primary = true;
            this.btnSalir_frmEmpleados.Size = new System.Drawing.Size(110, 35);
            this.btnSalir_frmEmpleados.TabIndex = 15;
            this.btnSalir_frmEmpleados.Text = "SALIR";
            this.btnSalir_frmEmpleados.UseVisualStyleBackColor = true;
            this.btnSalir_frmEmpleados.Click += new System.EventHandler(this.btnSalir_frmEmpleados_Click);
            // 
            // txtBoxIdEmpleados
            // 
            this.txtBoxIdEmpleados.Location = new System.Drawing.Point(40, 109);
            this.txtBoxIdEmpleados.Name = "txtBoxIdEmpleados";
            this.txtBoxIdEmpleados.Size = new System.Drawing.Size(37, 20);
            this.txtBoxIdEmpleados.TabIndex = 16;
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // frmEmpleados
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(700, 430);
            this.Controls.Add(this.txtBoxIdEmpleados);
            this.Controls.Add(this.btnSalir_frmEmpleados);
            this.Controls.Add(this.btnActualizar_frmEmpleados);
            this.Controls.Add(this.txtDatosAdicionales_frmEmpleados);
            this.Controls.Add(this.lblDatosAdicionales_frmEmpleados);
            this.Controls.Add(this.dtpFechaRetiro_frmEmpleados);
            this.Controls.Add(this.lblFRetiro_frmEmpleados);
            this.Controls.Add(this.dtpFechaIngreso_frmEmpleados);
            this.Controls.Add(this.lblFIngreso_frmEmpleados);
            this.Controls.Add(this.cboRol_frmEmpleados);
            this.Controls.Add(this.lblRolEmpleado_frmEmpleados);
            this.Controls.Add(this.txtEmail_frmEmpleados);
            this.Controls.Add(this.txtTelefono_frmEmpleados);
            this.Controls.Add(this.txtDireccion_frmEmpleados);
            this.Controls.Add(this.txtDocumento_frmEmpleados);
            this.Controls.Add(this.txtNombre_frmEmpleados);
            this.Controls.Add(this.lblTitulo_frmEmpleados);
            this.Name = "frmEmpleados";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Empleados";
            this.Load += new System.EventHandler(this.frmEmpleados_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MaterialSkin.Controls.MaterialLabel lblTitulo_frmEmpleados;
        private MaterialSkin.Controls.MaterialSingleLineTextField txtNombre_frmEmpleados;
        private MaterialSkin.Controls.MaterialSingleLineTextField txtDocumento_frmEmpleados;
        private MaterialSkin.Controls.MaterialSingleLineTextField txtDireccion_frmEmpleados;
        private MaterialSkin.Controls.MaterialSingleLineTextField txtTelefono_frmEmpleados;
        private MaterialSkin.Controls.MaterialSingleLineTextField txtEmail_frmEmpleados;
        private MaterialSkin.Controls.MaterialLabel lblRolEmpleado_frmEmpleados;
        private System.Windows.Forms.ComboBox cboRol_frmEmpleados;
        private MaterialSkin.Controls.MaterialLabel lblFIngreso_frmEmpleados;
        private System.Windows.Forms.DateTimePicker dtpFechaIngreso_frmEmpleados;
        private MaterialSkin.Controls.MaterialLabel lblFRetiro_frmEmpleados;
        private System.Windows.Forms.DateTimePicker dtpFechaRetiro_frmEmpleados;
        private MaterialSkin.Controls.MaterialLabel lblDatosAdicionales_frmEmpleados;
        private System.Windows.Forms.TextBox txtDatosAdicionales_frmEmpleados;
        private MaterialSkin.Controls.MaterialRaisedButton btnActualizar_frmEmpleados;
        private MaterialSkin.Controls.MaterialRaisedButton btnSalir_frmEmpleados;
        private System.Windows.Forms.TextBox txtBoxIdEmpleados;
        private System.Windows.Forms.ErrorProvider errorProvider1;
    }
}