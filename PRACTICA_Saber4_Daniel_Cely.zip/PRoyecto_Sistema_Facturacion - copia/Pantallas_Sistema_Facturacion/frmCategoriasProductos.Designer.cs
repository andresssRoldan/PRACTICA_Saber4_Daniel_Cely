﻿namespace Pantallas_Sistema_Facturacion
{
    partial class frmCategoriasProductos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mtlTituloCategoriaProductos = new MaterialSkin.Controls.MaterialLabel();
            this.mtlNombreCategoriaProductos = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.textBoxCategoriaProductos = new System.Windows.Forms.TextBox();
            this.btnActualizarCategoriaProductos = new MaterialSkin.Controls.MaterialRaisedButton();
            this.btnSalirCategoriaProductos = new MaterialSkin.Controls.MaterialRaisedButton();
            this.SuspendLayout();
            // 
            // mtlTituloCategoriaProductos
            // 
            this.mtlTituloCategoriaProductos.AutoSize = true;
            this.mtlTituloCategoriaProductos.Depth = 0;
            this.mtlTituloCategoriaProductos.Font = new System.Drawing.Font("Roboto", 11F);
            this.mtlTituloCategoriaProductos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.mtlTituloCategoriaProductos.Location = new System.Drawing.Point(262, 38);
            this.mtlTituloCategoriaProductos.MouseState = MaterialSkin.MouseState.HOVER;
            this.mtlTituloCategoriaProductos.Name = "mtlTituloCategoriaProductos";
            this.mtlTituloCategoriaProductos.Size = new System.Drawing.Size(203, 19);
            this.mtlTituloCategoriaProductos.TabIndex = 4;
            this.mtlTituloCategoriaProductos.Text = "CATEGORIA DE PRODUCTOS";
            // 
            // mtlNombreCategoriaProductos
            // 
            this.mtlNombreCategoriaProductos.Depth = 0;
            this.mtlNombreCategoriaProductos.Hint = "Nombre Categoria";
            this.mtlNombreCategoriaProductos.Location = new System.Drawing.Point(121, 145);
            this.mtlNombreCategoriaProductos.MouseState = MaterialSkin.MouseState.HOVER;
            this.mtlNombreCategoriaProductos.Name = "mtlNombreCategoriaProductos";
            this.mtlNombreCategoriaProductos.PasswordChar = '\0';
            this.mtlNombreCategoriaProductos.SelectedText = "";
            this.mtlNombreCategoriaProductos.SelectionLength = 0;
            this.mtlNombreCategoriaProductos.SelectionStart = 0;
            this.mtlNombreCategoriaProductos.Size = new System.Drawing.Size(134, 23);
            this.mtlNombreCategoriaProductos.TabIndex = 7;
            this.mtlNombreCategoriaProductos.UseSystemPasswordChar = false;
            // 
            // textBoxCategoriaProductos
            // 
            this.textBoxCategoriaProductos.Location = new System.Drawing.Point(121, 100);
            this.textBoxCategoriaProductos.Name = "textBoxCategoriaProductos";
            this.textBoxCategoriaProductos.Size = new System.Drawing.Size(37, 20);
            this.textBoxCategoriaProductos.TabIndex = 8;
            // 
            // btnActualizarCategoriaProductos
            // 
            this.btnActualizarCategoriaProductos.Depth = 0;
            this.btnActualizarCategoriaProductos.Location = new System.Drawing.Point(121, 310);
            this.btnActualizarCategoriaProductos.MouseState = MaterialSkin.MouseState.HOVER;
            this.btnActualizarCategoriaProductos.Name = "btnActualizarCategoriaProductos";
            this.btnActualizarCategoriaProductos.Primary = true;
            this.btnActualizarCategoriaProductos.Size = new System.Drawing.Size(134, 44);
            this.btnActualizarCategoriaProductos.TabIndex = 9;
            this.btnActualizarCategoriaProductos.Text = "ACTUALIZAR";
            this.btnActualizarCategoriaProductos.UseVisualStyleBackColor = true;
            // 
            // btnSalirCategoriaProductos
            // 
            this.btnSalirCategoriaProductos.Depth = 0;
            this.btnSalirCategoriaProductos.Location = new System.Drawing.Point(347, 310);
            this.btnSalirCategoriaProductos.MouseState = MaterialSkin.MouseState.HOVER;
            this.btnSalirCategoriaProductos.Name = "btnSalirCategoriaProductos";
            this.btnSalirCategoriaProductos.Primary = true;
            this.btnSalirCategoriaProductos.Size = new System.Drawing.Size(134, 44);
            this.btnSalirCategoriaProductos.TabIndex = 10;
            this.btnSalirCategoriaProductos.Text = "SALIR";
            this.btnSalirCategoriaProductos.UseVisualStyleBackColor = true;
            this.btnSalirCategoriaProductos.Click += new System.EventHandler(this.btnSalirCategoriaProductos_Click);
            // 
            // frmCategoriasProductos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnSalirCategoriaProductos);
            this.Controls.Add(this.btnActualizarCategoriaProductos);
            this.Controls.Add(this.textBoxCategoriaProductos);
            this.Controls.Add(this.mtlNombreCategoriaProductos);
            this.Controls.Add(this.mtlTituloCategoriaProductos);
            this.Name = "frmCategoriasProductos";
            this.Load += new System.EventHandler(this.frmCategoriasProductos_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MaterialSkin.Controls.MaterialLabel mtlTituloCategoriaProductos;
        private MaterialSkin.Controls.MaterialSingleLineTextField mtlNombreCategoriaProductos;
        private System.Windows.Forms.TextBox textBoxCategoriaProductos;
        private MaterialSkin.Controls.MaterialRaisedButton btnActualizarCategoriaProductos;
        private MaterialSkin.Controls.MaterialRaisedButton btnSalirCategoriaProductos;
    }
}