﻿namespace Pantallas_Sistema_Facturacion
{
    partial class frmFacturas
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

       
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pnlEncabezado_frmFacturas = new System.Windows.Forms.Panel();
            this.lblTitulo_frmFacturas = new System.Windows.Forms.Label();
            this.lblNroFactura_frmFacturas = new System.Windows.Forms.Label();
            this.txtNroFactura_frmFacturas = new System.Windows.Forms.TextBox();
            this.lblCliente_frmFacturas = new System.Windows.Forms.Label();
            this.cboCliente_frmFacturas = new System.Windows.Forms.ComboBox();
            this.lblEmpleado_frmFacturas = new System.Windows.Forms.Label();
            this.cboEmpleado_frmFacturas = new System.Windows.Forms.ComboBox();
            this.lblDescuento_frmFacturas = new System.Windows.Forms.Label();
            this.txtDescuento_frmFacturas = new System.Windows.Forms.TextBox();
            this.lblTotalIva_frmFacturas = new System.Windows.Forms.Label();
            this.txtTotalIva_frmFacturas = new System.Windows.Forms.TextBox();
            this.lblTotalFactura_frmFacturas = new System.Windows.Forms.Label();
            this.txtTotalFactura_frmFacturas = new System.Windows.Forms.TextBox();
            this.lblFechaRegistro_frmFacturas = new System.Windows.Forms.Label();
            this.dtpFechaRegistro_frmFacturas = new System.Windows.Forms.DateTimePicker();
            this.lblEstadoFactura_frmFacturas = new System.Windows.Forms.Label();
            this.cboEstadoFactura_frmFacturas = new System.Windows.Forms.ComboBox();
            this.btnActualizar_frmFacturas = new MaterialSkin.Controls.MaterialRaisedButton();
            this.pnlDetalle_frmFacturas = new System.Windows.Forms.Panel();
            this.lblDetalleFactura_frmFacturas = new System.Windows.Forms.Label();
            this.dgvDetalle_frmFacturas = new System.Windows.Forms.DataGridView();
            this.btnSalir_frmFacturas = new MaterialSkin.Controls.MaterialRaisedButton();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.pnlEncabezado_frmFacturas.SuspendLayout();
            this.pnlDetalle_frmFacturas.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDetalle_frmFacturas)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlEncabezado_frmFacturas
            // 
            this.pnlEncabezado_frmFacturas.BackColor = System.Drawing.Color.White;
            this.pnlEncabezado_frmFacturas.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlEncabezado_frmFacturas.Controls.Add(this.lblTitulo_frmFacturas);
            this.pnlEncabezado_frmFacturas.Controls.Add(this.lblNroFactura_frmFacturas);
            this.pnlEncabezado_frmFacturas.Controls.Add(this.txtNroFactura_frmFacturas);
            this.pnlEncabezado_frmFacturas.Controls.Add(this.lblCliente_frmFacturas);
            this.pnlEncabezado_frmFacturas.Controls.Add(this.cboCliente_frmFacturas);
            this.pnlEncabezado_frmFacturas.Controls.Add(this.lblEmpleado_frmFacturas);
            this.pnlEncabezado_frmFacturas.Controls.Add(this.cboEmpleado_frmFacturas);
            this.pnlEncabezado_frmFacturas.Controls.Add(this.lblDescuento_frmFacturas);
            this.pnlEncabezado_frmFacturas.Controls.Add(this.txtDescuento_frmFacturas);
            this.pnlEncabezado_frmFacturas.Controls.Add(this.lblTotalIva_frmFacturas);
            this.pnlEncabezado_frmFacturas.Controls.Add(this.txtTotalIva_frmFacturas);
            this.pnlEncabezado_frmFacturas.Controls.Add(this.lblTotalFactura_frmFacturas);
            this.pnlEncabezado_frmFacturas.Controls.Add(this.txtTotalFactura_frmFacturas);
            this.pnlEncabezado_frmFacturas.Controls.Add(this.lblFechaRegistro_frmFacturas);
            this.pnlEncabezado_frmFacturas.Controls.Add(this.dtpFechaRegistro_frmFacturas);
            this.pnlEncabezado_frmFacturas.Controls.Add(this.lblEstadoFactura_frmFacturas);
            this.pnlEncabezado_frmFacturas.Controls.Add(this.cboEstadoFactura_frmFacturas);
            this.pnlEncabezado_frmFacturas.Controls.Add(this.btnActualizar_frmFacturas);
            this.pnlEncabezado_frmFacturas.Location = new System.Drawing.Point(15, 75);
            this.pnlEncabezado_frmFacturas.Name = "pnlEncabezado_frmFacturas";
            this.pnlEncabezado_frmFacturas.Size = new System.Drawing.Size(770, 210);
            this.pnlEncabezado_frmFacturas.TabIndex = 0;
            // 
            // lblTitulo_frmFacturas
            // 
            this.lblTitulo_frmFacturas.AutoSize = true;
            this.lblTitulo_frmFacturas.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblTitulo_frmFacturas.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblTitulo_frmFacturas.Location = new System.Drawing.Point(280, 10);
            this.lblTitulo_frmFacturas.Name = "lblTitulo_frmFacturas";
            this.lblTitulo_frmFacturas.Size = new System.Drawing.Size(233, 21);
            this.lblTitulo_frmFacturas.TabIndex = 0;
            this.lblTitulo_frmFacturas.Text = "ADMINISTRACIÓN FACTURAS";
            // 
            // lblNroFactura_frmFacturas
            // 
            this.lblNroFactura_frmFacturas.AutoSize = true;
            this.lblNroFactura_frmFacturas.Location = new System.Drawing.Point(30, 48);
            this.lblNroFactura_frmFacturas.Name = "lblNroFactura_frmFacturas";
            this.lblNroFactura_frmFacturas.Size = new System.Drawing.Size(66, 13);
            this.lblNroFactura_frmFacturas.TabIndex = 1;
            this.lblNroFactura_frmFacturas.Text = "Nro Factura:";
            // 
            // txtNroFactura_frmFacturas
            // 
            this.txtNroFactura_frmFacturas.Location = new System.Drawing.Point(110, 45);
            this.txtNroFactura_frmFacturas.Name = "txtNroFactura_frmFacturas";
            this.txtNroFactura_frmFacturas.Size = new System.Drawing.Size(150, 20);
            this.txtNroFactura_frmFacturas.TabIndex = 1;
            // 
            // lblCliente_frmFacturas
            // 
            this.lblCliente_frmFacturas.AutoSize = true;
            this.lblCliente_frmFacturas.Location = new System.Drawing.Point(30, 75);
            this.lblCliente_frmFacturas.Name = "lblCliente_frmFacturas";
            this.lblCliente_frmFacturas.Size = new System.Drawing.Size(42, 13);
            this.lblCliente_frmFacturas.TabIndex = 2;
            this.lblCliente_frmFacturas.Text = "Cliente:";
            // 
            // cboCliente_frmFacturas
            // 
            this.cboCliente_frmFacturas.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboCliente_frmFacturas.FormattingEnabled = true;
            this.cboCliente_frmFacturas.Location = new System.Drawing.Point(110, 72);
            this.cboCliente_frmFacturas.Name = "cboCliente_frmFacturas";
            this.cboCliente_frmFacturas.Size = new System.Drawing.Size(260, 21);
            this.cboCliente_frmFacturas.TabIndex = 2;
            // 
            // lblEmpleado_frmFacturas
            // 
            this.lblEmpleado_frmFacturas.AutoSize = true;
            this.lblEmpleado_frmFacturas.Location = new System.Drawing.Point(30, 102);
            this.lblEmpleado_frmFacturas.Name = "lblEmpleado_frmFacturas";
            this.lblEmpleado_frmFacturas.Size = new System.Drawing.Size(57, 13);
            this.lblEmpleado_frmFacturas.TabIndex = 3;
            this.lblEmpleado_frmFacturas.Text = "Empleado:";
            // 
            // cboEmpleado_frmFacturas
            // 
            this.cboEmpleado_frmFacturas.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboEmpleado_frmFacturas.FormattingEnabled = true;
            this.cboEmpleado_frmFacturas.Location = new System.Drawing.Point(110, 99);
            this.cboEmpleado_frmFacturas.Name = "cboEmpleado_frmFacturas";
            this.cboEmpleado_frmFacturas.Size = new System.Drawing.Size(260, 21);
            this.cboEmpleado_frmFacturas.TabIndex = 3;
            // 
            // lblDescuento_frmFacturas
            // 
            this.lblDescuento_frmFacturas.AutoSize = true;
            this.lblDescuento_frmFacturas.Location = new System.Drawing.Point(30, 129);
            this.lblDescuento_frmFacturas.Name = "lblDescuento_frmFacturas";
            this.lblDescuento_frmFacturas.Size = new System.Drawing.Size(62, 13);
            this.lblDescuento_frmFacturas.TabIndex = 4;
            this.lblDescuento_frmFacturas.Text = "Descuento:";
            // 
            // txtDescuento_frmFacturas
            // 
            this.txtDescuento_frmFacturas.Location = new System.Drawing.Point(110, 126);
            this.txtDescuento_frmFacturas.Name = "txtDescuento_frmFacturas";
            this.txtDescuento_frmFacturas.Size = new System.Drawing.Size(150, 20);
            this.txtDescuento_frmFacturas.TabIndex = 4;
            // 
            // lblTotalIva_frmFacturas
            // 
            this.lblTotalIva_frmFacturas.AutoSize = true;
            this.lblTotalIva_frmFacturas.Location = new System.Drawing.Point(30, 156);
            this.lblTotalIva_frmFacturas.Name = "lblTotalIva_frmFacturas";
            this.lblTotalIva_frmFacturas.Size = new System.Drawing.Size(52, 13);
            this.lblTotalIva_frmFacturas.TabIndex = 5;
            this.lblTotalIva_frmFacturas.Text = "Total Iva:";
            // 
            // txtTotalIva_frmFacturas
            // 
            this.txtTotalIva_frmFacturas.Location = new System.Drawing.Point(110, 153);
            this.txtTotalIva_frmFacturas.Name = "txtTotalIva_frmFacturas";
            this.txtTotalIva_frmFacturas.Size = new System.Drawing.Size(150, 20);
            this.txtTotalIva_frmFacturas.TabIndex = 5;
            // 
            // lblTotalFactura_frmFacturas
            // 
            this.lblTotalFactura_frmFacturas.AutoSize = true;
            this.lblTotalFactura_frmFacturas.Location = new System.Drawing.Point(30, 183);
            this.lblTotalFactura_frmFacturas.Name = "lblTotalFactura_frmFacturas";
            this.lblTotalFactura_frmFacturas.Size = new System.Drawing.Size(70, 13);
            this.lblTotalFactura_frmFacturas.TabIndex = 6;
            this.lblTotalFactura_frmFacturas.Text = "Total factura:";
            // 
            // txtTotalFactura_frmFacturas
            // 
            this.txtTotalFactura_frmFacturas.Location = new System.Drawing.Point(110, 180);
            this.txtTotalFactura_frmFacturas.Name = "txtTotalFactura_frmFacturas";
            this.txtTotalFactura_frmFacturas.Size = new System.Drawing.Size(150, 20);
            this.txtTotalFactura_frmFacturas.TabIndex = 6;
            // 
            // lblFechaRegistro_frmFacturas
            // 
            this.lblFechaRegistro_frmFacturas.AutoSize = true;
            this.lblFechaRegistro_frmFacturas.Location = new System.Drawing.Point(420, 48);
            this.lblFechaRegistro_frmFacturas.Name = "lblFechaRegistro_frmFacturas";
            this.lblFechaRegistro_frmFacturas.Size = new System.Drawing.Size(82, 13);
            this.lblFechaRegistro_frmFacturas.TabIndex = 7;
            this.lblFechaRegistro_frmFacturas.Text = "Fecha Registro:";
            // 
            // dtpFechaRegistro_frmFacturas
            // 
            this.dtpFechaRegistro_frmFacturas.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFechaRegistro_frmFacturas.Location = new System.Drawing.Point(423, 68);
            this.dtpFechaRegistro_frmFacturas.Name = "dtpFechaRegistro_frmFacturas";
            this.dtpFechaRegistro_frmFacturas.Size = new System.Drawing.Size(130, 20);
            this.dtpFechaRegistro_frmFacturas.TabIndex = 7;
            // 
            // lblEstadoFactura_frmFacturas
            // 
            this.lblEstadoFactura_frmFacturas.AutoSize = true;
            this.lblEstadoFactura_frmFacturas.Location = new System.Drawing.Point(420, 102);
            this.lblEstadoFactura_frmFacturas.Name = "lblEstadoFactura_frmFacturas";
            this.lblEstadoFactura_frmFacturas.Size = new System.Drawing.Size(82, 13);
            this.lblEstadoFactura_frmFacturas.TabIndex = 8;
            this.lblEstadoFactura_frmFacturas.Text = "Estado Factura:";
            // 
            // cboEstadoFactura_frmFacturas
            // 
            this.cboEstadoFactura_frmFacturas.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboEstadoFactura_frmFacturas.FormattingEnabled = true;
            this.cboEstadoFactura_frmFacturas.Location = new System.Drawing.Point(423, 122);
            this.cboEstadoFactura_frmFacturas.Name = "cboEstadoFactura_frmFacturas";
            this.cboEstadoFactura_frmFacturas.Size = new System.Drawing.Size(130, 21);
            this.cboEstadoFactura_frmFacturas.TabIndex = 8;
            // 
            // btnActualizar_frmFacturas
            // 
            this.btnActualizar_frmFacturas.Depth = 0;
            this.btnActualizar_frmFacturas.Location = new System.Drawing.Point(620, 95);
            this.btnActualizar_frmFacturas.MouseState = MaterialSkin.MouseState.HOVER;
            this.btnActualizar_frmFacturas.Name = "btnActualizar_frmFacturas";
            this.btnActualizar_frmFacturas.Primary = true;
            this.btnActualizar_frmFacturas.Size = new System.Drawing.Size(120, 40);
            this.btnActualizar_frmFacturas.TabIndex = 9;
            this.btnActualizar_frmFacturas.Text = "ACTUALIZAR";
            this.btnActualizar_frmFacturas.UseVisualStyleBackColor = true;
            this.btnActualizar_frmFacturas.Click += new System.EventHandler(this.btnActualizar_frmFacturas_Click_1);
            // 
            // pnlDetalle_frmFacturas
            // 
            this.pnlDetalle_frmFacturas.BackColor = System.Drawing.Color.White;
            this.pnlDetalle_frmFacturas.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlDetalle_frmFacturas.Controls.Add(this.lblDetalleFactura_frmFacturas);
            this.pnlDetalle_frmFacturas.Controls.Add(this.dgvDetalle_frmFacturas);
            this.pnlDetalle_frmFacturas.Controls.Add(this.btnSalir_frmFacturas);
            this.pnlDetalle_frmFacturas.Location = new System.Drawing.Point(15, 295);
            this.pnlDetalle_frmFacturas.Name = "pnlDetalle_frmFacturas";
            this.pnlDetalle_frmFacturas.Size = new System.Drawing.Size(770, 240);
            this.pnlDetalle_frmFacturas.TabIndex = 1;
            // 
            // lblDetalleFactura_frmFacturas
            // 
            this.lblDetalleFactura_frmFacturas.AutoSize = true;
            this.lblDetalleFactura_frmFacturas.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblDetalleFactura_frmFacturas.Location = new System.Drawing.Point(15, 10);
            this.lblDetalleFactura_frmFacturas.Name = "lblDetalleFactura_frmFacturas";
            this.lblDetalleFactura_frmFacturas.Size = new System.Drawing.Size(109, 15);
            this.lblDetalleFactura_frmFacturas.TabIndex = 0;
            this.lblDetalleFactura_frmFacturas.Text = "DETALLE FACTURA";
            // 
            // dgvDetalle_frmFacturas
            // 
            this.dgvDetalle_frmFacturas.AllowUserToAddRows = false;
            this.dgvDetalle_frmFacturas.AllowUserToDeleteRows = false;
            this.dgvDetalle_frmFacturas.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDetalle_frmFacturas.BackgroundColor = System.Drawing.Color.LightGray;
            this.dgvDetalle_frmFacturas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDetalle_frmFacturas.Location = new System.Drawing.Point(18, 30);
            this.dgvDetalle_frmFacturas.Name = "dgvDetalle_frmFacturas";
            this.dgvDetalle_frmFacturas.ReadOnly = true;
            this.dgvDetalle_frmFacturas.Size = new System.Drawing.Size(580, 190);
            this.dgvDetalle_frmFacturas.TabIndex = 1;
            // 
            // btnSalir_frmFacturas
            // 
            this.btnSalir_frmFacturas.Depth = 0;
            this.btnSalir_frmFacturas.Location = new System.Drawing.Point(630, 180);
            this.btnSalir_frmFacturas.MouseState = MaterialSkin.MouseState.HOVER;
            this.btnSalir_frmFacturas.Name = "btnSalir_frmFacturas";
            this.btnSalir_frmFacturas.Primary = true;
            this.btnSalir_frmFacturas.Size = new System.Drawing.Size(110, 40);
            this.btnSalir_frmFacturas.TabIndex = 2;
            this.btnSalir_frmFacturas.Text = "SALIR";
            this.btnSalir_frmFacturas.UseVisualStyleBackColor = true;
            this.btnSalir_frmFacturas.Click += new System.EventHandler(this.btnSalir_frmFacturas_Click);
            // 
            // errorProvider1
            // 
            this.errorProvider1.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.NeverBlink;
            this.errorProvider1.ContainerControl = this;
            // 
            // frmFacturas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 550);
            this.Controls.Add(this.pnlEncabezado_frmFacturas);
            this.Controls.Add(this.pnlDetalle_frmFacturas);
            this.MaximizeBox = false;
            this.Name = "frmFacturas";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Gestión de Facturas";
            this.Load += new System.EventHandler(this.frmFacturas_Load_1);
            this.pnlEncabezado_frmFacturas.ResumeLayout(false);
            this.pnlEncabezado_frmFacturas.PerformLayout();
            this.pnlDetalle_frmFacturas.ResumeLayout(false);
            this.pnlDetalle_frmFacturas.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDetalle_frmFacturas)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlEncabezado_frmFacturas;
        private System.Windows.Forms.Label lblTitulo_frmFacturas;
        private System.Windows.Forms.Label lblNroFactura_frmFacturas;
        private System.Windows.Forms.TextBox txtNroFactura_frmFacturas;
        private System.Windows.Forms.Label lblCliente_frmFacturas;
        private System.Windows.Forms.ComboBox cboCliente_frmFacturas;
        private System.Windows.Forms.Label lblEmpleado_frmFacturas;
        private System.Windows.Forms.ComboBox cboEmpleado_frmFacturas;
        private System.Windows.Forms.Label lblDescuento_frmFacturas;
        private System.Windows.Forms.TextBox txtDescuento_frmFacturas;
        private System.Windows.Forms.Label lblTotalIva_frmFacturas;
        private System.Windows.Forms.TextBox txtTotalIva_frmFacturas;
        private System.Windows.Forms.Label lblTotalFactura_frmFacturas;
        private System.Windows.Forms.TextBox txtTotalFactura_frmFacturas;
        private System.Windows.Forms.Label lblFechaRegistro_frmFacturas;
        private System.Windows.Forms.DateTimePicker dtpFechaRegistro_frmFacturas;
        private System.Windows.Forms.Label lblEstadoFactura_frmFacturas;
        private System.Windows.Forms.ComboBox cboEstadoFactura_frmFacturas;
        private MaterialSkin.Controls.MaterialRaisedButton btnActualizar_frmFacturas;

        private System.Windows.Forms.Panel pnlDetalle_frmFacturas;
        private System.Windows.Forms.Label lblDetalleFactura_frmFacturas;
        private System.Windows.Forms.DataGridView dgvDetalle_frmFacturas;
        private MaterialSkin.Controls.MaterialRaisedButton btnSalir_frmFacturas;
        private System.Windows.Forms.ErrorProvider errorProvider1;
    }
}